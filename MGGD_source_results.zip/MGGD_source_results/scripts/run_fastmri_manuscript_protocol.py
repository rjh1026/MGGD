"""Reproduce the manuscript-style fastMRI multicoil protocol.

Protocol:
1. Estimate multiscale GGD prior from train references.
2. Tune method-specific regularization on validation data.
3. Freeze selected parameters and evaluate test data.
4. Save metrics, pairwise significance tests, and per-case intermediate figures.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import sys
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import h5py
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import optimize, special, stats

try:
    import torch
except ImportError:
    torch = None

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import run_fastmri_subset_experiment as fmri
import run_synthetic_mggd_experiment as core


Array = np.ndarray
METRICS = ["NMSE", "PSNR", "SSIM"]
METHODS = ["SENSE", "Tikhonov", "BE", "WaveletL1", "TV", "MGGD"]
SOLVER_DEVICE = "cpu"
GPU_DTYPE = "float32"


def configure_process_resources(cpu_core_limit: int, low_priority: bool) -> None:
    if sys.platform != "win32":
        return
    import ctypes

    kernel32 = ctypes.windll.kernel32
    process = kernel32.GetCurrentProcess()
    if cpu_core_limit > 0:
        available = max(1, os.cpu_count() or 1)
        cores = min(cpu_core_limit, available)
        mask = (1 << cores) - 1
        if not kernel32.SetProcessAffinityMask(process, mask):
            print(
                "warning: Windows denied the CPU affinity mask; "
                "continuing with library thread limits.",
                flush=True,
            )
    if low_priority:
        below_normal_priority_class = 0x00004000
        if not kernel32.SetPriorityClass(process, below_normal_priority_class):
            print(
                "warning: Windows denied the low-priority request; continuing.",
                flush=True,
            )


@dataclass(frozen=True)
class Case:
    split: str
    path: Path
    slice_idx: int

    @property
    def case_id(self) -> str:
        return f"{self.path.stem}_slice{self.slice_idx}"


def stable_seed(*parts: object, base: int = 0) -> int:
    text = "|".join(str(part) for part in parts)
    value = int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:8], 16)
    return (value + base) % (2**32 - 1)


def parse_float_grid(text: str) -> List[float]:
    return [float(item) for item in text.split(",") if item.strip()]


def ggd_ratio(p: float) -> float:
    return float(special.gamma(2.0 / p) / math.sqrt(special.gamma(1.0 / p) * special.gamma(3.0 / p)))


def estimate_ggd_params(values: Array) -> Dict[str, float]:
    vals = np.asarray(values, dtype=float)
    vals = vals[np.isfinite(vals)]
    vals = vals[vals > 1e-8]
    if vals.size < 16:
        return {"alpha": 1e-3, "p": 1.0, "lambda_base": 1e3, "n": int(vals.size)}

    ratio = float(np.mean(vals) / max(math.sqrt(float(np.mean(vals**2))), 1e-12))

    def objective(p: float) -> float:
        return (ggd_ratio(p) - ratio) ** 2

    result = optimize.minimize_scalar(objective, bounds=(0.25, 4.0), method="bounded")
    p_hat = float(result.x if result.success else 1.0)
    second = float(np.mean(vals**2))
    alpha = math.sqrt(max(second * special.gamma(1.0 / p_hat) / special.gamma(3.0 / p_hat), 1e-12))
    lambda_base = float(alpha ** (-p_hat))
    return {"alpha": alpha, "p": p_hat, "lambda_base": lambda_base, "n": int(vals.size)}


def iter_cases(
    split: str,
    data_dir: Path,
    acquisition: str | None,
    max_files: int,
    max_slices: int,
    file_offset: int = 0,
) -> List[Case]:
    files = list(fmri.iter_h5_files(data_dir, acquisition))[file_offset : file_offset + max_files]
    cases: List[Case] = []
    for path in files:
        for slice_idx in fmri.slice_indices(path, max_slices):
            cases.append(Case(split=split, path=path, slice_idx=slice_idx))
    return cases


def cases_from_manifest(manifest: Path, split: str) -> List[Case]:
    table = pd.read_csv(manifest)
    required = {"path", "slice_idx"}
    missing = required - set(table.columns)
    if missing:
        raise ValueError(f"{manifest} is missing columns: {sorted(missing)}")
    cases = []
    for row in table.itertuples(index=False):
        path = Path(str(row.path))
        if not path.exists():
            raise FileNotFoundError(f"Manifest data file does not exist: {path}")
        cases.append(Case(split=split, path=path, slice_idx=int(row.slice_idx)))
    return cases


def estimate_train_prior(cases: Iterable[Case], cfg: core.ReconConfig, crop_size: int, coils: int) -> Dict[str, Dict[str, float]]:
    values_by_band: Dict[str, List[Array]] = {}
    for case in cases:
        sens, truth, _ = fmri.load_slice_from_h5(case.path, case.slice_idx, crop_size)
        sens = fmri.compress_sensitivity_maps(sens, coils)
        ref = np.abs(truth)
        arr, coeff_slices = core.wavelet_array(ref, cfg.wavelet, cfg.wavelet_level)
        for key, slc in core.detail_slices(coeff_slices):
            values_by_band.setdefault(key, []).append(np.abs(arr[slc]).ravel())

    prior: Dict[str, Dict[str, float]] = {}
    for key, chunks in values_by_band.items():
        prior[key] = estimate_ggd_params(np.concatenate(chunks))
    return prior


def prior_scales(prior: Dict[str, Dict[str, float]]) -> Dict[str, float]:
    return {key: float(value["alpha"]) for key, value in prior.items()}


def tv_weights(x: Array, lam: float, eps: float) -> Tuple[Array, Array]:
    dx = np.roll(x, -1, axis=0) - x
    dy = np.roll(x, -1, axis=1) - x
    mag = np.sqrt(np.abs(dx) ** 2 + np.abs(dy) ** 2 + eps)
    w = lam / np.maximum(2.0 * mag, eps)
    return w, w


def tv_operator(x: Array, wx: Array, wy: Array) -> Array:
    dx = np.roll(x, -1, axis=0) - x
    dy = np.roll(x, -1, axis=1) - x
    vx = wx * dx
    vy = wy * dy
    return (np.roll(vx, 1, axis=0) - vx) + (np.roll(vy, 1, axis=1) - vy)


def complex_to_torch(x: Array, device, dtype):
    stacked = np.stack((np.real(x), np.imag(x)), axis=-1)
    return torch.from_numpy(stacked).to(device=device, dtype=dtype)


def torch_complex_mul(a, b):
    real = a[..., 0] * b[..., 0] - a[..., 1] * b[..., 1]
    imag = a[..., 0] * b[..., 1] + a[..., 1] * b[..., 0]
    return torch.stack((real, imag), dim=-1)


def torch_complex_conj(x):
    return torch.stack((x[..., 0], -x[..., 1]), dim=-1)


def torch_fft2(x):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return torch.fft(x, 2, normalized=True)


def torch_ifft2(x):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return torch.ifft(x, 2, normalized=True)


def torch_forward(x, sens, mask):
    coil_images = torch_complex_mul(sens, x[:, None, :, :, :])
    return torch_fft2(coil_images) * mask[:, None, :, :, None]


def torch_adjoint(y, sens, mask):
    coil_images = torch_ifft2(y * mask[:, None, :, :, None])
    return torch_complex_mul(torch_complex_conj(sens), coil_images).sum(dim=1)


def torch_laplacian(x):
    return (
        -4.0 * x
        + torch.roll(x, 1, dims=1)
        + torch.roll(x, -1, dims=1)
        + torch.roll(x, 1, dims=2)
        + torch.roll(x, -1, dims=2)
    )


def torch_tv_operator(x, wx, wy):
    dx = torch.roll(x, -1, dims=1) - x
    dy = torch.roll(x, -1, dims=2) - x
    vx = wx * dx
    vy = wy * dy
    return (torch.roll(vx, 1, dims=1) - vx) + (torch.roll(vy, 1, dims=2) - vy)


def solve_normal_extra_cuda(
    rhs: Array,
    sens: Array,
    mask: Array,
    cfg: core.ReconConfig,
    ridge: float = 0.0,
    tikhonov: float = 0.0,
    bending: float = 0.0,
    tv_wx: Array | None = None,
    tv_wy: Array | None = None,
    x0: Array | None = None,
) -> Array:
    if torch is None or not torch.cuda.is_available():
        raise RuntimeError("CUDA solver requested but PyTorch CUDA is unavailable.")

    device = torch.device("cuda")
    dtype = torch.float64 if GPU_DTYPE == "float64" else torch.float32
    with torch.no_grad():
        rhs_t = complex_to_torch(rhs, device, dtype).unsqueeze(0)
        sens_t = complex_to_torch(sens, device, dtype).unsqueeze(0)
        mask_t = torch.from_numpy(mask.astype(np.float32)).to(device=device, dtype=dtype).unsqueeze(0)
        x = complex_to_torch(x0 if x0 is not None else np.zeros_like(rhs), device, dtype).unsqueeze(0)
        wx_t = (
            torch.from_numpy(tv_wx).to(device=device, dtype=dtype)[None, :, :, None]
            if tv_wx is not None
            else None
        )
        wy_t = (
            torch.from_numpy(tv_wy).to(device=device, dtype=dtype)[None, :, :, None]
            if tv_wy is not None
            else None
        )

        def matvec(v):
            out = torch_adjoint(torch_forward(v, sens_t, mask_t), sens_t, mask_t)
            if ridge:
                out = out + ridge * v
            if tikhonov:
                out = out + tikhonov * v
            if bending:
                out = out + bending * torch_laplacian(torch_laplacian(v))
            if wx_t is not None and wy_t is not None:
                out = out + torch_tv_operator(v, wx_t, wy_t)
            return out

        r = rhs_t - matvec(x)
        direction = r.clone()
        residual_sq = torch.sum(r * r)
        rhs_norm = torch.sqrt(torch.clamp(torch.sum(rhs_t * rhs_t), min=1e-30))
        converged = False
        iterations = 0
        for iterations in range(1, cfg.cg_maxiter + 1):
            applied = matvec(direction)
            denominator = torch.sum(direction * applied)
            if torch.abs(denominator).item() < 1e-30:
                break
            alpha = residual_sq / denominator
            x = x + alpha * direction
            r = r - alpha * applied
            new_residual_sq = torch.sum(r * r)
            if torch.sqrt(torch.clamp(new_residual_sq, min=0.0)) <= cfg.cg_rtol * rhs_norm:
                converged = True
                residual_sq = new_residual_sq
                break
            beta = new_residual_sq / torch.clamp(residual_sq, min=1e-30)
            direction = r + beta * direction
            residual_sq = new_residual_sq

        if not converged:
            print(f"warning: CUDA CG ended after {iterations} iterations", flush=True)
        result = x[0].detach().cpu().numpy()
    return result[..., 0] + 1j * result[..., 1]


def mggd_weights_from_prior(
    x: Array,
    cfg: core.ReconConfig,
    coeff_slices: list,
    prior: Dict[str, Dict[str, float]],
    global_scale: float,
) -> Array:
    arr, _ = core.wavelet_array(x, cfg.wavelet, cfg.wavelet_level)
    weights = np.zeros_like(arr, dtype=float)
    for key, slc in core.detail_slices(coeff_slices):
        params = prior.get(key)
        if not params:
            continue
        p = float(params["p"])
        lam = global_scale * float(params["lambda_base"])
        coeff_abs2 = np.abs(arr[slc]) ** 2
        weights[slc] = lam * (p / 2.0) * (coeff_abs2 + cfg.irls_eps) ** (p / 2.0 - 1.0)
    return weights


def solve_normal_extra(
    rhs: Array,
    sens: Array,
    mask: Array,
    cfg: core.ReconConfig,
    ridge: float = 0.0,
    tikhonov: float = 0.0,
    bending: float = 0.0,
    wavelet_weights: Array | None = None,
    coeff_slices: list | None = None,
    tv_wx: Array | None = None,
    tv_wy: Array | None = None,
    x0: Array | None = None,
) -> Array:
    if SOLVER_DEVICE == "cuda" and wavelet_weights is None:
        return solve_normal_extra_cuda(
            rhs,
            sens,
            mask,
            cfg,
            ridge=ridge,
            tikhonov=tikhonov,
            bending=bending,
            tv_wx=tv_wx,
            tv_wy=tv_wy,
            x0=x0,
        )

    def matvec(x: Array) -> Array:
        out = core.adjoint(core.forward(x, sens, mask), sens, mask)
        if ridge:
            out = out + ridge * x
        if tikhonov:
            out = out + tikhonov * x
        if bending:
            out = out + bending * core.bending_operator(x)
        if wavelet_weights is not None:
            assert coeff_slices is not None
            out = out + core.wavelet_quadratic_operator(x, wavelet_weights, coeff_slices, cfg)
        if tv_wx is not None and tv_wy is not None:
            out = out + tv_operator(x, tv_wx, tv_wy)
        return out

    x = np.zeros_like(rhs) if x0 is None else np.array(x0, copy=True)
    residual = rhs - matvec(x)
    direction = residual.copy()
    residual_sq = float(np.vdot(residual, residual).real)
    target = float(cfg.cg_rtol * np.linalg.norm(rhs))
    converged = False
    iterations = 0
    for iterations in range(1, cfg.cg_maxiter + 1):
        applied = matvec(direction)
        denominator = float(np.vdot(direction, applied).real)
        if abs(denominator) < 1e-30:
            break
        alpha = residual_sq / denominator
        x = x + alpha * direction
        residual = residual - alpha * applied
        new_residual_sq = float(np.vdot(residual, residual).real)
        if math.sqrt(max(new_residual_sq, 0.0)) <= target:
            converged = True
            residual_sq = new_residual_sq
            break
        beta = new_residual_sq / max(residual_sq, 1e-30)
        direction = residual + beta * direction
        residual_sq = new_residual_sq
    if not converged:
        print(f"warning: CPU CG ended after {iterations} iterations", flush=True)
    return x


def reconstruct_protocol(
    method: str,
    y: Array,
    sens: Array,
    mask: Array,
    cfg: core.ReconConfig,
    params: Dict[str, float],
    prior: Dict[str, Dict[str, float]],
) -> Array:
    rhs = core.adjoint(y, sens, mask)
    coeff_slices = core.coeff_slices_for_shape(rhs.shape, cfg.wavelet, cfg.wavelet_level)
    x0 = rhs
    ridge = float(params.get("ridge", 1e-6))

    if method == "SENSE":
        return solve_normal_extra(rhs, sens, mask, cfg, ridge=ridge, x0=x0)
    if method == "Tikhonov":
        return solve_normal_extra(
            rhs, sens, mask, cfg, ridge=ridge, tikhonov=float(params["tikhonov"]), x0=x0
        )
    if method == "BE":
        return solve_normal_extra(
            rhs, sens, mask, cfg, ridge=ridge, bending=float(params["bending"]), x0=x0
        )
    if method == "WaveletL1":
        method_params = core.MethodParams(
            ridge=ridge,
            bending=float(params.get("bending", 0.0)),
            wavelet_l1=float(params["wavelet_l1"]),
            mggd_scale=1.0,
            mggd_p=1.0,
        )
        x = x0
        for _ in range(cfg.irls_iters):
            weights = core.make_wavelet_weights(
                x,
                cfg,
                coeff_slices,
                "l1",
                method_params,
                prior_scales(prior),
            )
            x = solve_normal_extra(
                rhs,
                sens,
                mask,
                cfg,
                ridge=ridge,
                wavelet_weights=weights,
                coeff_slices=coeff_slices,
                x0=x,
            )
        return x
    if method == "TV":
        x = x0
        lam = float(params["tv"])
        for _ in range(cfg.irls_iters):
            wx, wy = tv_weights(x, lam=lam, eps=cfg.irls_eps)
            x = solve_normal_extra(rhs, sens, mask, cfg, ridge=ridge, tv_wx=wx, tv_wy=wy, x0=x)
        return x
    if method == "MGGD":
        x = x0
        for _ in range(cfg.irls_iters):
            weights = mggd_weights_from_prior(
                x,
                cfg,
                coeff_slices,
                prior,
                global_scale=float(params["mggd_scale"]),
            )
            x = solve_normal_extra(
                rhs,
                sens,
                mask,
                cfg,
                ridge=ridge,
                bending=float(params.get("bending", 0.0)),
                wavelet_weights=weights,
                coeff_slices=coeff_slices,
                x0=x,
            )
        return x
    raise ValueError(f"Unknown method: {method}")


def read_cropped_kspace(path: Path, slice_idx: int, crop_size: int) -> Array:
    with h5py.File(path, "r") as hf:
        kspace = np.asarray(hf["kspace"][slice_idx])
    if not np.iscomplexobj(kspace) and kspace.shape[-1] == 2:
        kspace = kspace[..., 0] + 1j * kspace[..., 1]
    kspace = fmri.center_crop_2d(kspace, crop_size)
    kspace, _ = fmri.normalize_kspace(kspace)
    return kspace


def save_scalar_image(path: Path, image: Array, cmap: str = "gray", vmin=None, vmax=None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(4.0, 4.0))
    ax.imshow(image, cmap=cmap, vmin=vmin, vmax=vmax)
    ax.axis("off")
    fig.tight_layout(pad=0)
    fig.savefig(path, dpi=180)
    plt.close(fig)


def save_sensitivity_montage(path: Path, sens: Array, max_coils: int = 8) -> None:
    n = min(max_coils, sens.shape[0])
    cols = min(4, n)
    rows = int(math.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(3.0 * cols, 3.0 * rows))
    axes_arr = np.asarray(axes).reshape(-1)
    for idx, ax in enumerate(axes_arr):
        ax.axis("off")
        if idx < n:
            ax.imshow(np.abs(sens[idx]), cmap="gray")
            ax.set_title(f"coil {idx}")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def save_case_figures(
    out_dir: Path,
    case: Case,
    acceleration: int,
    kspace: Array,
    sens: Array,
    mask: Array,
    truth: Array,
    recon_by_method: Dict[str, Array],
) -> None:
    case_dir = out_dir / "figures" / case.split / f"{case.case_id}_R{acceleration}"
    case_dir.mkdir(parents=True, exist_ok=True)

    ref = np.abs(truth)
    vmax = max(float(np.percentile(ref, 99.5)), 1e-6)
    kspace_log = np.log1p(np.sqrt(np.sum(np.abs(kspace) ** 2, axis=0)) if kspace.ndim == 3 else np.abs(kspace))
    zero_filled = np.abs(core.adjoint(core.forward(truth, sens, mask), sens, mask))

    save_scalar_image(case_dir / "reference.png", ref, "gray", 0, vmax)
    save_scalar_image(case_dir / "kspace_log.png", kspace_log, "magma")
    save_scalar_image(case_dir / "mask.png", mask.astype(float), "gray", 0, 1)
    save_scalar_image(case_dir / "zero_filled.png", zero_filled, "gray", 0, vmax)
    save_sensitivity_montage(case_dir / "sensitivity_magnitude.png", sens)

    for method, recon in recon_by_method.items():
        pred = np.abs(recon)
        err = np.abs(pred - ref)
        save_scalar_image(case_dir / f"{method}_recon.png", pred, "gray", 0, vmax)
        save_scalar_image(case_dir / f"{method}_error.png", err, "magma", 0, max(0.35, float(np.percentile(err, 99))))

    methods = list(recon_by_method)
    cols = len(methods) + 2
    fig, axes = plt.subplots(2, cols, figsize=(3.0 * cols, 6.0))
    axes[0, 0].imshow(ref, cmap="gray", vmin=0, vmax=vmax)
    axes[0, 0].set_title("Reference")
    axes[1, 0].imshow(np.zeros_like(ref), cmap="magma", vmin=0, vmax=0.35)
    axes[1, 0].set_title("Error")
    axes[0, 1].imshow(zero_filled, cmap="gray", vmin=0, vmax=vmax)
    axes[0, 1].set_title("Zero-filled")
    axes[1, 1].imshow(np.abs(zero_filled - ref), cmap="magma", vmin=0, vmax=0.35)
    axes[1, 1].set_title("|error|")
    for col, method in enumerate(methods, start=2):
        pred = np.abs(recon_by_method[method])
        axes[0, col].imshow(pred, cmap="gray", vmin=0, vmax=vmax)
        axes[0, col].set_title(method)
        axes[1, col].imshow(np.abs(pred - ref), cmap="magma", vmin=0, vmax=0.35)
        axes[1, col].set_title("|error|")
    for ax in axes.ravel():
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(case_dir / "comparison_grid.png", dpi=160)
    plt.close(fig)

    np.savez_compressed(
        case_dir / "intermediates.npz",
        reference=ref,
        mask=mask.astype(np.uint8),
        zero_filled=zero_filled,
        **{f"{method}_recon": np.abs(recon) for method, recon in recon_by_method.items()},
    )


def default_params(args: argparse.Namespace) -> Dict[str, Dict[str, float]]:
    return {
        "SENSE": {"ridge": args.ridge},
        "Tikhonov": {"ridge": args.ridge, "tikhonov": args.tikhonov_grid[0]},
        "BE": {"ridge": args.ridge, "bending": args.bending_grid[0]},
        "WaveletL1": {"ridge": args.ridge, "wavelet_l1": args.wavelet_l1_grid[0]},
        "TV": {"ridge": args.ridge, "tv": args.tv_grid[0]},
        "MGGD": {"ridge": args.ridge, "bending": args.default_bending, "mggd_scale": args.mggd_scale_grid[0]},
    }


def candidate_grid(method: str, args: argparse.Namespace) -> List[Dict[str, float]]:
    if method == "SENSE":
        return [{"ridge": args.ridge}]
    if method == "Tikhonov":
        return [{"ridge": args.ridge, "tikhonov": value} for value in args.tikhonov_grid]
    if method == "BE":
        return [{"ridge": args.ridge, "bending": value} for value in args.bending_grid]
    if method == "WaveletL1":
        return [{"ridge": args.ridge, "wavelet_l1": value} for value in args.wavelet_l1_grid]
    if method == "TV":
        return [{"ridge": args.ridge, "tv": value} for value in args.tv_grid]
    if method == "MGGD":
        return [
            {"ridge": args.ridge, "bending": args.default_bending, "mggd_scale": value}
            for value in args.mggd_scale_grid
        ]
    raise ValueError(method)


def run_reconstruction_set(
    split: str,
    cases: List[Case],
    cfg: core.ReconConfig,
    prior: Dict[str, Dict[str, float]],
    params_by_method: Dict[str, Dict[str, float]],
    accelerations: List[int],
    crop_size: int,
    coils: int,
    noise_sigma: float,
    seed: int,
    methods: List[str],
    out_dir: Path,
    save_figures: bool,
    noise_repeats: int = 0,
    resume: bool = False,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    metric_rows = []
    noise_rows = []

    for case in cases:
        kspace = read_cropped_kspace(case.path, case.slice_idx, crop_size)
        sens, truth, _ = fmri.load_slice_from_h5(case.path, case.slice_idx, crop_size)
        sens = fmri.compress_sensitivity_maps(sens, coils)

        for acceleration in accelerations:
            case_dir = out_dir / "figures" / split / f"{case.case_id}_R{acceleration}"
            cached_path = case_dir / "intermediates.npz"
            if resume and save_figures and noise_repeats == 0 and cached_path.exists():
                try:
                    with np.load(cached_path, allow_pickle=False) as cached:
                        expected_keys = ["reference", *[f"{method}_recon" for method in methods]]
                        missing_keys = [key for key in expected_keys if key not in cached.files]
                        if missing_keys:
                            raise ValueError(f"missing keys: {missing_keys}")
                        if cached["reference"].shape != np.abs(truth).shape:
                            raise ValueError(
                                f"reference shape {cached['reference'].shape} "
                                f"does not match truth shape {np.abs(truth).shape}"
                            )
                        recon_by_method = {
                            method: np.asarray(cached[f"{method}_recon"])
                            for method in methods
                        }

                    print(
                        f"resume=skip split={split} file={case.path.name} "
                        f"slice={case.slice_idx} R={acceleration}",
                        flush=True,
                    )
                    for method in methods:
                        row = {
                            "split": split,
                            "file": case.path.name,
                            "slice": case.slice_idx,
                            "case_id": case.case_id,
                            "acquisition": fmri.acquisition_name(case.path),
                            "acceleration": acceleration,
                            "method": method,
                        }
                        row.update(core.metrics(recon_by_method[method], truth))
                        metric_rows.append(row)
                    continue
                except Exception as exc:
                    print(
                        f"warning: ignoring invalid resume cache {cached_path}: {exc}",
                        flush=True,
                    )

            rng = np.random.default_rng(stable_seed(split, case.path.name, case.slice_idx, acceleration, base=seed))
            mask = core.make_mask(crop_size, acceleration, rng)
            y_clean = core.forward(truth, sens, mask)
            y = core.add_complex_noise(y_clean, mask, noise_sigma, rng)

            recon_by_method: Dict[str, Array] = {}
            for method in methods:
                print(
                    f"split={split} file={case.path.name} slice={case.slice_idx} R={acceleration} method={method}",
                    flush=True,
                )
                recon = reconstruct_protocol(
                    method,
                    y,
                    sens,
                    mask,
                    cfg,
                    params_by_method[method],
                    prior,
                )
                recon_by_method[method] = recon
                row = {
                    "split": split,
                    "file": case.path.name,
                    "slice": case.slice_idx,
                    "case_id": case.case_id,
                    "acquisition": fmri.acquisition_name(case.path),
                    "acceleration": acceleration,
                    "method": method,
                }
                row.update(core.metrics(recon, truth))
                metric_rows.append(row)

            if save_figures:
                save_case_figures(out_dir, case, acceleration, kspace, sens, mask, truth, recon_by_method)

            if noise_repeats > 1:
                noise_recons = {method: [] for method in methods}
                for rep in range(noise_repeats):
                    rep_rng = np.random.default_rng(
                        stable_seed(split, case.path.name, case.slice_idx, acceleration, rep, base=seed + 10000)
                    )
                    y_rep = core.add_complex_noise(y_clean, mask, noise_sigma, rep_rng)
                    for method in methods:
                        noise_recons[method].append(
                            reconstruct_protocol(
                                method,
                                y_rep,
                                sens,
                                mask,
                                cfg,
                                params_by_method[method],
                                prior,
                            )
                        )
                noise_df = summarize_and_save_noise_maps(
                    out_dir, case, acceleration, noise_recons, split=split
                )
                noise_rows.extend(noise_df.to_dict(orient="records"))

    return pd.DataFrame(metric_rows), pd.DataFrame(noise_rows)


def summarize_and_save_noise_maps(
    out_dir: Path,
    case: Case,
    acceleration: int,
    noise_recons: Dict[str, List[Array]],
    split: str,
) -> pd.DataFrame:
    case_dir = out_dir / "figures" / split / f"{case.case_id}_R{acceleration}"
    case_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    variances = {}
    means = {}
    for method, values in noise_recons.items():
        stack = np.stack([np.abs(value) for value in values], axis=0)
        means[method] = np.mean(stack, axis=0)
        variances[method] = np.var(stack, axis=0, ddof=1 if stack.shape[0] > 1 else 0)

    sense_var = np.maximum(variances["SENSE"], 1e-12)
    foreground = means["SENSE"] > 0.05 * np.max(means["SENSE"])

    for method in noise_recons:
        var = variances[method]
        snr = means[method] / np.sqrt(np.maximum(var, 1e-12))
        geff_ratio = np.sqrt(var / sense_var)
        save_scalar_image(case_dir / f"{method}_variance.png", var, "viridis", 0, np.percentile(sense_var, 99))
        save_scalar_image(case_dir / f"{method}_snr.png", snr, "magma")
        save_scalar_image(case_dir / f"{method}_geff_ratio_vs_sense.png", geff_ratio, "coolwarm", 0, 2)
        rows.append(
            {
                "split": split,
                "file": case.path.name,
                "slice": case.slice_idx,
                "case_id": case.case_id,
                "acceleration": acceleration,
                "method": method,
                "median_variance": float(np.median(var[foreground])),
                "median_snr": float(np.median(snr[foreground])),
                "median_var_ratio_vs_sense": float(np.median((var / sense_var)[foreground])),
                "median_geff_ratio_vs_sense": float(np.median(geff_ratio[foreground])),
            }
        )
    return pd.DataFrame(rows)


def summarize_metrics(metrics_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for keys, group in metrics_df.groupby(["split", "acceleration", "method"]):
        split, acceleration, method = keys
        row = {"split": split, "acceleration": acceleration, "method": method, "n": len(group)}
        for metric in METRICS:
            values = group[metric].astype(float).to_numpy()
            row[f"{metric}_mean"] = float(np.mean(values))
            row[f"{metric}_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else float("nan")
            row[f"{metric}_median"] = float(np.median(values))
            if len(values) > 1:
                sem = stats.sem(values)
                ci = stats.t.ppf(0.975, len(values) - 1) * sem
                row[f"{metric}_ci95_low"] = float(np.mean(values) - ci)
                row[f"{metric}_ci95_high"] = float(np.mean(values) + ci)
            else:
                row[f"{metric}_ci95_low"] = float("nan")
                row[f"{metric}_ci95_high"] = float("nan")
        rows.append(row)
    return pd.DataFrame(rows)


def pairwise_significance(metrics_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (split, acceleration), group in metrics_df.groupby(["split", "acceleration"]):
        for metric in METRICS:
            pivot = group.pivot_table(index="case_id", columns="method", values=metric, aggfunc="mean")
            for method_a, method_b in itertools.combinations(sorted(pivot.columns), 2):
                paired = pivot[[method_a, method_b]].dropna()
                n = len(paired)
                a = paired[method_a].astype(float).to_numpy()
                b = paired[method_b].astype(float).to_numpy()
                diff = a - b
                if n >= 2 and np.any(np.abs(diff) > 1e-12):
                    t_p = float(stats.ttest_rel(a, b, nan_policy="omit").pvalue)
                    try:
                        w_p = float(stats.wilcoxon(a, b, zero_method="wilcox").pvalue)
                    except ValueError:
                        w_p = float("nan")
                else:
                    t_p = float("nan")
                    w_p = float("nan")
                rows.append(
                    {
                        "split": split,
                        "acceleration": acceleration,
                        "metric": metric,
                        "method_a": method_a,
                        "method_b": method_b,
                        "n_pairs": n,
                        "mean_a_minus_b": float(np.mean(diff)) if n else float("nan"),
                        "paired_t_p": t_p,
                        "wilcoxon_p": w_p,
                        "lower_is_better": metric == "NMSE",
                    }
                )
    result = pd.DataFrame(rows)
    if result.empty:
        return result
    for raw_column in ["paired_t_p", "wilcoxon_p"]:
        adjusted_column = f"{raw_column}_holm"
        result[adjusted_column] = float("nan")
        for _, indices in result.groupby(["split", "acceleration", "metric"]).groups.items():
            valid = result.loc[indices, raw_column].dropna().sort_values()
            count = len(valid)
            running_max = 0.0
            for rank, (index, value) in enumerate(valid.items()):
                adjusted = min(1.0, float(value) * (count - rank))
                running_max = max(running_max, adjusted)
                result.loc[index, adjusted_column] = running_max
        result[f"{adjusted_column}_significant_0_05"] = result[adjusted_column] < 0.05
    return result


def aggregate_metrics_by_volume(metrics_df: pd.DataFrame) -> pd.DataFrame:
    volume_metrics = (
        metrics_df.groupby(["split", "file", "acceleration", "method"], as_index=False)[METRICS]
        .mean()
        .rename(columns={"file": "case_id"})
    )
    return volume_metrics




def select_params(validation_df: pd.DataFrame, score_metric: str) -> Dict[str, Dict[str, float]]:
    selected: Dict[str, Dict[str, float]] = {}
    ascending = score_metric == "NMSE"
    for method, group in validation_df.groupby("method"):
        summary = (
            group.groupby("param_id", as_index=False)
            .agg(score=(score_metric, "mean"), params_json=("params_json", "first"))
            .sort_values("score", ascending=ascending)
        )
        best = summary.iloc[0]
        selected[method] = json.loads(best["params_json"])
    return selected


def tune_on_validation(
    cases: List[Case],
    cfg: core.ReconConfig,
    prior: Dict[str, Dict[str, float]],
    args: argparse.Namespace,
    out_dir: Path,
    methods: List[str],
) -> Tuple[pd.DataFrame, Dict[str, Dict[str, float]]]:
    rows = []
    for method in methods:
        for param_idx, params in enumerate(candidate_grid(method, args)):
            param_id = f"{method}_{param_idx:02d}"
            metrics_df, _ = run_reconstruction_set(
                split="validation",
                cases=cases,
                cfg=cfg,
                prior=prior,
                params_by_method={method: params},
                accelerations=args.accelerations,
                crop_size=args.crop_size,
                coils=args.coils,
                noise_sigma=args.noise_sigma,
                seed=args.seed,
                methods=[method],
                out_dir=out_dir,
                save_figures=False,
                noise_repeats=0,
            )
            metrics_df["param_id"] = param_id
            metrics_df["params_json"] = json.dumps(params, sort_keys=True)
            rows.append(metrics_df)
    validation_df = pd.concat(rows, ignore_index=True)
    selected = select_params(validation_df, args.score_metric)
    return validation_df, selected


def run(args: argparse.Namespace) -> None:
    global SOLVER_DEVICE, GPU_DTYPE

    configure_process_resources(args.cpu_core_limit, args.low_priority)
    SOLVER_DEVICE = args.solver_device
    if SOLVER_DEVICE == "auto":
        SOLVER_DEVICE = "cuda" if torch is not None and torch.cuda.is_available() else "cpu"
    if SOLVER_DEVICE == "cuda" and (torch is None or not torch.cuda.is_available()):
        raise SystemExit("CUDA solver requested but PyTorch CUDA is unavailable.")
    GPU_DTYPE = args.gpu_dtype

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    methods = [method for method in args.methods if method in METHODS]

    cfg = core.ReconConfig(
        image_size=args.crop_size,
        coils=args.coils,
        noise_sigma=args.noise_sigma,
        cg_maxiter=args.cg_maxiter,
        irls_iters=args.irls_iters,
        seed=args.seed,
    )

    if args.train_manifest:
        train_cases = cases_from_manifest(Path(args.train_manifest), "train")
    else:
        train_cases = iter_cases(
            "train",
            Path(args.train_dir),
            args.acquisition,
            args.max_train_files,
            args.max_train_slices,
            args.train_file_offset,
        )
    if args.val_manifest:
        val_cases = cases_from_manifest(Path(args.val_manifest), "validation")
    else:
        val_cases = iter_cases(
            "validation",
            Path(args.val_dir),
            args.acquisition,
            args.max_val_files,
            args.max_val_slices,
            args.val_file_offset,
        )
    if args.test_manifest:
        test_cases = cases_from_manifest(Path(args.test_manifest), "test")
    else:
        test_cases = iter_cases(
            "test",
            Path(args.test_dir),
            args.acquisition,
            args.max_test_files,
            args.max_test_slices,
            args.test_file_offset,
        )
    if not train_cases:
        raise SystemExit("No train cases found.")
    if not val_cases:
        raise SystemExit("No validation cases found.")
    if not test_cases:
        raise SystemExit("No test cases found.")

    prior_path = out_dir / "trained_prior.json"
    if args.resume and prior_path.exists():
        prior = json.loads(prior_path.read_text(encoding="utf-8"))
        print(f"Reusing trained prior from {prior_path.resolve()}", flush=True)
    else:
        prior = estimate_train_prior(train_cases, cfg, args.crop_size, args.coils)
        prior_path.write_text(json.dumps(prior, indent=2), encoding="utf-8")

    validation_path = out_dir / "validation_tuning_metrics.csv"
    selected_path = out_dir / "selected_params.json"
    reuse_validation = False
    if args.resume and validation_path.exists() and selected_path.exists():
        try:
            validation_df = pd.read_csv(validation_path)
            selected = json.loads(selected_path.read_text(encoding="utf-8"))
            missing_methods = [method for method in methods if method not in selected]
            if missing_methods:
                raise ValueError(f"selected parameters missing methods: {missing_methods}")
            reuse_validation = True
            print(
                f"Reusing validation tuning from {validation_path.resolve()}",
                flush=True,
            )
        except Exception as exc:
            print(f"warning: validation resume cache is invalid: {exc}", flush=True)

    if not reuse_validation:
        validation_df, selected = tune_on_validation(val_cases, cfg, prior, args, out_dir, methods)
        validation_df.to_csv(validation_path, index=False)
        selected_path.write_text(json.dumps(selected, indent=2), encoding="utf-8")

    test_metrics, noise_df = run_reconstruction_set(
        split="test",
        cases=test_cases,
        cfg=cfg,
        prior=prior,
        params_by_method=selected,
        accelerations=args.accelerations,
        crop_size=args.crop_size,
        coils=args.coils,
        noise_sigma=args.noise_sigma,
        seed=args.seed,
        methods=methods,
        out_dir=out_dir,
        save_figures=True,
        noise_repeats=0,
        resume=args.resume,
    )
    if args.noise_repeats > 1:
        one_case_per_volume = {}
        for case in test_cases:
            one_case_per_volume.setdefault(case.path, case)
        ranked_noise_cases = sorted(
            one_case_per_volume.values(),
            key=lambda case: stable_seed("noise-case", case.path.name, base=args.seed),
        )
        noise_cases = ranked_noise_cases[: args.noise_max_volumes]
        _, noise_df = run_reconstruction_set(
            split="noise",
            cases=noise_cases,
            cfg=cfg,
            prior=prior,
            params_by_method=selected,
            accelerations=args.noise_accelerations,
            crop_size=args.crop_size,
            coils=args.coils,
            noise_sigma=args.noise_sigma,
            seed=args.seed,
            methods=methods,
            out_dir=out_dir,
            save_figures=False,
            noise_repeats=args.noise_repeats,
        )
    test_metrics.to_csv(out_dir / "test_metrics.csv", index=False)
    summary_df = summarize_metrics(test_metrics)
    summary_df.to_csv(out_dir / "test_metric_summary_by_model.csv", index=False)
    significance_df = pairwise_significance(test_metrics)
    significance_df.to_csv(out_dir / "test_pairwise_significance_all_pairs.csv", index=False)
    volume_metrics = aggregate_metrics_by_volume(test_metrics)
    volume_metrics.to_csv(out_dir / "test_metrics_by_volume.csv", index=False)
    summarize_metrics(volume_metrics).to_csv(
        out_dir / "test_metric_summary_by_volume.csv",
        index=False,
    )
    pairwise_significance(volume_metrics).to_csv(
        out_dir / "test_pairwise_significance_by_volume.csv",
        index=False,
    )
    if not noise_df.empty:
        noise_df.to_csv(out_dir / "test_noise_summary.csv", index=False)

    run_summary = {
        "dataset_name": args.dataset_name,
        "train_dir": args.train_dir,
        "val_dir": args.val_dir,
        "test_dir": args.test_dir,
        "train_manifest": args.train_manifest,
        "validation_manifest": args.val_manifest,
        "test_manifest": args.test_manifest,
        "train_cases": [case.case_id for case in train_cases],
        "validation_cases": [case.case_id for case in val_cases],
        "test_cases": [case.case_id for case in test_cases],
        "config": cfg.__dict__,
        "accelerations": args.accelerations,
        "methods": methods,
        "selected_params": selected,
        "solver_device": SOLVER_DEVICE,
        "gpu_dtype": GPU_DTYPE if SOLVER_DEVICE == "cuda" else None,
    }
    (out_dir / "run_summary.json").write_text(json.dumps(run_summary, indent=2), encoding="utf-8")

    print("\n=== Selected parameters ===")
    print(json.dumps(selected, indent=2))
    print("\n=== Test metric summary ===")
    print(summary_df.to_string(index=False))
    print("\n=== Pairwise significance ===")
    print(significance_df.to_string(index=False))
    if not noise_df.empty:
        print("\n=== Noise summary ===")
        print(noise_df.to_string(index=False))
    print(f"\nSaved manuscript protocol outputs to {out_dir.resolve()}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-name", default="fastmri_multicoil")
    parser.add_argument("--train-dir")
    parser.add_argument("--val-dir")
    parser.add_argument("--test-dir")
    parser.add_argument("--train-manifest")
    parser.add_argument("--val-manifest")
    parser.add_argument("--test-manifest")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--acquisition", default=None)
    parser.add_argument("--max-train-files", type=int, default=2)
    parser.add_argument("--max-val-files", type=int, default=1)
    parser.add_argument("--max-test-files", type=int, default=2)
    parser.add_argument("--train-file-offset", type=int, default=0)
    parser.add_argument("--val-file-offset", type=int, default=0)
    parser.add_argument("--test-file-offset", type=int, default=0)
    parser.add_argument("--max-train-slices", type=int, default=1)
    parser.add_argument("--max-val-slices", type=int, default=1)
    parser.add_argument("--max-test-slices", type=int, default=2)
    parser.add_argument("--crop-size", type=int, default=96)
    parser.add_argument("--coils", type=int, default=8)
    parser.add_argument("--accelerations", type=int, nargs="+", default=[2, 4, 6, 8])
    parser.add_argument("--methods", nargs="+", default=METHODS)
    parser.add_argument("--noise-repeats", type=int, default=0)
    parser.add_argument("--noise-max-volumes", type=int, default=5)
    parser.add_argument("--noise-accelerations", type=int, nargs="+", default=[8])
    parser.add_argument("--noise-sigma", type=float, default=0.01)
    parser.add_argument("--irls-iters", type=int, default=10)
    parser.add_argument("--cg-maxiter", type=int, default=100)
    parser.add_argument("--seed", type=int, default=23)
    parser.add_argument("--ridge", type=float, default=1e-6)
    parser.add_argument("--default-bending", type=float, default=2e-3)
    parser.add_argument("--score-metric", choices=METRICS, default="SSIM")
    parser.add_argument("--tikhonov-grid", type=parse_float_grid, default=parse_float_grid("5e-4,2e-3,8e-3"))
    parser.add_argument("--bending-grid", type=parse_float_grid, default=parse_float_grid("5e-4,2e-3,8e-3"))
    parser.add_argument("--wavelet-l1-grid", type=parse_float_grid, default=parse_float_grid("1e-4,4e-4,1.6e-3"))
    parser.add_argument("--tv-grid", type=parse_float_grid, default=parse_float_grid("1e-4,4e-4,1.6e-3"))
    parser.add_argument("--mggd-scale-grid", type=parse_float_grid, default=parse_float_grid("2e-6,8e-6,3.2e-5"))
    parser.add_argument("--solver-device", choices=["cpu", "cuda", "auto"], default="cpu")
    parser.add_argument("--gpu-dtype", choices=["float32", "float64"], default="float32")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--cpu-core-limit", type=int, default=0)
    parser.add_argument("--low-priority", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
