"""Run a small real fastMRI multi-coil subset experiment.

This is intentionally a subset runner, not a bulk downloader. The official
fastMRI raw data require a Data Sharing Agreement and user-specific download
link, so this script assumes `.h5` files already exist locally.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Iterable, Tuple

import h5py
import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import run_synthetic_mggd_experiment as core


Array = np.ndarray


def fft2c(x: Array) -> Array:
    x = np.fft.ifftshift(x, axes=(-2, -1))
    x = np.fft.fft2(x, axes=(-2, -1), norm="ortho")
    return np.fft.fftshift(x, axes=(-2, -1))


def ifft2c(x: Array) -> Array:
    x = np.fft.ifftshift(x, axes=(-2, -1))
    x = np.fft.ifft2(x, axes=(-2, -1), norm="ortho")
    return np.fft.fftshift(x, axes=(-2, -1))


def center_crop_2d(x: Array, crop_size: int) -> Array:
    h, w = x.shape[-2:]
    if crop_size > min(h, w):
        raise ValueError(f"crop_size={crop_size} exceeds k-space shape {(h, w)}")
    h0 = (h - crop_size) // 2
    w0 = (w - crop_size) // 2
    return x[..., h0 : h0 + crop_size, w0 : w0 + crop_size]


def normalize_kspace(kspace: Array) -> Tuple[Array, float]:
    scale = np.percentile(np.abs(kspace), 99)
    scale = float(scale if scale > 0 else np.max(np.abs(kspace)))
    if scale <= 0:
        scale = 1.0
    return kspace / scale, scale


def sensitivity_from_coil_images(coil_images: Array, eps: float = 1e-8) -> Tuple[Array, Array]:
    if coil_images.ndim == 2:
        obj = coil_images
        sens = np.ones((1,) + obj.shape, dtype=np.complex128)
        return sens, obj

    rss = np.sqrt(np.sum(np.abs(coil_images) ** 2, axis=0))
    sens = coil_images / np.maximum(rss[None, :, :], eps)
    obj = np.sum(np.conj(sens) * coil_images, axis=0) / np.maximum(
        np.sum(np.abs(sens) ** 2, axis=0), eps
    )
    return sens, obj


def compress_sensitivity_maps(sens: Array, coils: int) -> Array:
    """Energy-preserving virtual-coil compression using the coil covariance."""
    if coils <= 0 or sens.shape[0] <= coils:
        return sens
    flat = sens.reshape(sens.shape[0], -1)
    covariance = flat @ flat.conj().T
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    basis = eigenvectors[:, np.argsort(eigenvalues)[::-1][:coils]]
    compressed = basis.conj().T @ flat
    return compressed.reshape((coils,) + sens.shape[1:])


def load_slice_from_h5(path: Path, slice_idx: int, crop_size: int) -> Tuple[Array, Array, Array]:
    with h5py.File(path, "r") as hf:
        kspace = hf["kspace"][slice_idx]
        kspace = np.asarray(kspace)

    if not np.iscomplexobj(kspace) and kspace.shape[-1] == 2:
        kspace = kspace[..., 0] + 1j * kspace[..., 1]

    kspace = center_crop_2d(kspace, crop_size)
    kspace, _ = normalize_kspace(kspace)
    coil_images = ifft2c(kspace)
    sens, obj = sensitivity_from_coil_images(coil_images)
    if coil_images.ndim == 2:
        rss = np.abs(coil_images)
    else:
        rss = np.sqrt(np.sum(np.abs(coil_images) ** 2, axis=0))
    if np.max(rss) > 0:
        rss = rss / np.max(rss)
        obj = obj / np.max(np.abs(obj))
    return sens.astype(np.complex128), obj.astype(np.complex128), rss.astype(float)


def acquisition_name(path: Path) -> str:
    try:
        with h5py.File(path, "r") as hf:
            value = hf.attrs.get("acquisition", "")
    except OSError:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def iter_h5_files(data_dir: Path, acquisition: str | None) -> Iterable[Path]:
    for path in sorted(data_dir.rglob("*.h5")):
        if acquisition and acquisition_name(path) != acquisition:
            continue
        yield path


def slice_indices(path: Path, max_slices: int) -> list[int]:
    with h5py.File(path, "r") as hf:
        n_slices = int(hf["kspace"].shape[0])
    center = n_slices // 2
    offsets = [0]
    for step in range(1, max_slices):
        offsets.append(step if step % 2 else -(step // 2))
    indices = []
    for offset in offsets:
        idx = min(max(center + offset, 0), n_slices - 1)
        if idx not in indices:
            indices.append(idx)
    return indices[:max_slices]


def run(args: argparse.Namespace) -> None:
    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    files = list(iter_h5_files(data_dir, args.acquisition))[: args.max_files]
    if not files:
        raise SystemExit(
            "No fastMRI .h5 files found. Download/extract official fastMRI knee "
            "multi-coil data after completing the NYU data access process, then "
            "rerun with --data-dir pointing to that folder."
        )

    cfg = core.ReconConfig(
        image_size=args.crop_size,
        coils=args.coils,
        noise_sigma=args.noise_sigma,
        cg_maxiter=args.cg_maxiter,
        irls_iters=args.irls_iters,
        seed=args.seed,
    )
    params = core.MethodParams(
        ridge=args.ridge,
        tikhonov=args.tikhonov,
        bending=args.bending,
        wavelet_l1=args.wavelet_l1,
        mggd_scale=args.mggd_scale,
        mggd_p=args.mggd_p,
    )

    rng = np.random.default_rng(args.seed)
    methods = ["SENSE", "Tikhonov", "BE", "WaveletL1", "MGGD"]
    metric_rows = []
    noise_rows = []

    for file_idx, path in enumerate(files):
        for slice_idx in slice_indices(path, args.max_slices):
            sens, truth, rss_ref = load_slice_from_h5(path, slice_idx, args.crop_size)
            if args.coils and sens.shape[0] > args.coils:
                sens = sens[: args.coils]
            subband_scales = core.estimate_subband_scales(truth, cfg)

            for acceleration in args.accelerations:
                mask = core.make_mask(args.crop_size, acceleration, rng)
                y_clean = core.forward(truth, sens, mask)
                y = core.add_complex_noise(y_clean, mask, args.noise_sigma, rng)

                recon_by_method: Dict[str, Array] = {}
                for method in methods:
                    print(
                        f"file={path.name} slice={slice_idx} R={acceleration} method={method}",
                        flush=True,
                    )
                    recon = core.reconstruct(method, y, sens, mask, cfg, params, subband_scales)
                    recon_by_method[method] = recon
                    row = {
                        "file": path.name,
                        "slice": slice_idx,
                        "acquisition": acquisition_name(path),
                        "acceleration": acceleration,
                        "method": method,
                    }
                    row.update(core.metrics(recon, truth))
                    metric_rows.append(row)

                fig_stem = f"{path.stem}_slice{slice_idx}_R{acceleration}"
                core.save_figure(truth, recon_by_method, acceleration, out_dir)
                (out_dir / f"recon_R{acceleration}.png").replace(out_dir / f"recon_{fig_stem}.png")

                if args.noise_repeats > 1 and acceleration in args.noise_accelerations:
                    noise_recons = {method: [] for method in methods}
                    for rep in range(args.noise_repeats):
                        rep_rng = np.random.default_rng(args.seed + 100000 * file_idx + 1000 * rep)
                        y_rep = core.add_complex_noise(y_clean, mask, args.noise_sigma, rep_rng)
                        for method in methods:
                            noise_recons[method].append(
                                core.reconstruct(
                                    method, y_rep, sens, mask, cfg, params, subband_scales
                                )
                            )
                    noise_df = core.summarize_noise(noise_recons)
                    noise_df.insert(0, "file", path.name)
                    noise_df.insert(1, "slice", slice_idx)
                    noise_df.insert(2, "acceleration", acceleration)
                    noise_rows.extend(noise_df.to_dict(orient="records"))
                    core.save_noise_figure(noise_recons, acceleration, out_dir)
                    (out_dir / f"variance_R{acceleration}.png").replace(
                        out_dir / f"variance_{fig_stem}.png"
                    )

    metrics_df = pd.DataFrame(metric_rows)
    metrics_df.to_csv(out_dir / "fastmri_subset_metrics.csv", index=False)

    noise_df = pd.DataFrame(noise_rows)
    if not noise_df.empty:
        noise_df.to_csv(out_dir / "fastmri_subset_noise_summary.csv", index=False)

    summary = {
        "data_dir": str(data_dir),
        "files": [str(path) for path in files],
        "config": cfg.__dict__,
        "method_params": params.__dict__,
        "metrics": metric_rows,
        "noise_summary": noise_rows,
    }
    (out_dir / "fastmri_subset_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print("\n=== fastMRI subset fidelity metrics ===")
    print(metrics_df.to_string(index=False))
    if not noise_df.empty:
        print("\n=== fastMRI subset noise summary ===")
        print(noise_df.to_string(index=False))
    print(f"\nSaved outputs to {out_dir.resolve()}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--out-dir", default="outputs/fastmri_subset")
    parser.add_argument("--acquisition", default=None)
    parser.add_argument("--max-files", type=int, default=1)
    parser.add_argument("--max-slices", type=int, default=1)
    parser.add_argument("--crop-size", type=int, default=128)
    parser.add_argument("--coils", type=int, default=8)
    parser.add_argument("--accelerations", type=int, nargs="+", default=[4, 8])
    parser.add_argument("--noise-accelerations", type=int, nargs="+", default=[8])
    parser.add_argument("--noise-repeats", type=int, default=0)
    parser.add_argument("--noise-sigma", type=float, default=0.01)
    parser.add_argument("--irls-iters", type=int, default=6)
    parser.add_argument("--cg-maxiter", type=int, default=80)
    parser.add_argument("--seed", type=int, default=13)
    parser.add_argument("--ridge", type=float, default=1e-6)
    parser.add_argument("--tikhonov", type=float, default=2e-3)
    parser.add_argument("--bending", type=float, default=2e-3)
    parser.add_argument("--wavelet-l1", type=float, default=4e-4)
    parser.add_argument("--mggd-scale", type=float, default=8e-4)
    parser.add_argument("--mggd-p", type=float, default=0.75)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
