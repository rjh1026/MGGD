"""Create leakage-free, deterministic manifests for a 30% fastMRI study.

The training subset is sampled at the HDF5 volume level. The official
validation volumes are split into a calibration set and a held-out local test
set because the official challenge test targets are not publicly available.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import h5py
import pandas as pd


def stable_rank(path: Path, seed: int) -> str:
    text = f"{seed}|{path.name}"
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def acquisition_name(path: Path) -> str:
    try:
        with h5py.File(path, "r") as hf:
            value = hf.attrs.get("acquisition", "")
    except OSError:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def has_kspace(path: Path) -> bool:
    try:
        with h5py.File(path, "r") as hf:
            return "kspace" in hf and int(hf["kspace"].shape[0]) > 0
    except OSError:
        return False


def discover(root: Path, acquisition: str | None) -> list[Path]:
    files = [path.resolve() for path in root.rglob("*.h5") if has_kspace(path)]
    if acquisition:
        files = [path for path in files if acquisition_name(path) == acquisition]
    return sorted(files, key=lambda path: path.name)


def center_slices(path: Path, count: int) -> list[int]:
    with h5py.File(path, "r") as hf:
        total = int(hf["kspace"].shape[0])
    if count <= 0 or count >= total:
        return list(range(total))
    center = total // 2
    offsets = [0]
    distance = 1
    while len(offsets) < count:
        offsets.extend([-distance, distance])
        distance += 1
    return sorted({min(max(center + offset, 0), total - 1) for offset in offsets[:count]})


def choose(files: list[Path], fraction: float, seed: int) -> list[Path]:
    count = max(1, int(round(len(files) * fraction)))
    ranked = sorted(files, key=lambda path: stable_rank(path, seed))
    return sorted(ranked[:count], key=lambda path: path.name)


def manifest_rows(
    files: list[Path],
    split: str,
    slice_count: int,
    dataset_name: str,
) -> list[dict]:
    rows = []
    for path in files:
        for slice_idx in center_slices(path, slice_count):
            rows.append(
                {
                    "dataset": dataset_name,
                    "split": split,
                    "volume_id": path.stem,
                    "path": str(path),
                    "slice_idx": slice_idx,
                    "acquisition": acquisition_name(path),
                }
            )
    return rows


def require_complete(
    found: int,
    expected: int,
    split: str,
    allow_incomplete: bool,
) -> None:
    if expected <= 0 or found >= expected:
        return
    message = (
        f"{split}: found {found} volumes but expected at least {expected}. "
        "Refusing to label an incomplete local folder as a 30% study."
    )
    if allow_incomplete:
        print(f"WARNING: {message}", flush=True)
        return
    raise SystemExit(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(args: argparse.Namespace) -> None:
    train_files = discover(args.train_dir, args.acquisition)
    source_val_files = discover(args.source_val_dir, args.acquisition)
    source_test_files = (
        discover(args.test_dir, args.acquisition) if args.test_dir is not None else []
    )
    require_complete(
        len(train_files),
        args.expected_train_volumes,
        "train",
        args.allow_incomplete,
    )
    require_complete(
        len(source_val_files),
        args.expected_validation_volumes,
        "validation",
        args.allow_incomplete,
    )
    if args.test_dir is None and len(source_val_files) < 2:
        raise SystemExit("At least two validation volumes are required for calibration/test separation.")

    if args.target_train_volumes > 0:
        if len(train_files) < args.target_train_volumes:
            raise SystemExit(
                f"train: found {len(train_files)} volumes but target is "
                f"{args.target_train_volumes}."
            )
        ranked_train = sorted(train_files, key=lambda path: stable_rank(path, args.seed))
        selected_train = sorted(
            ranked_train[: args.target_train_volumes],
            key=lambda path: path.name,
        )
    else:
        selected_train = choose(train_files, args.train_fraction, args.seed)
    ranked_val = sorted(source_val_files, key=lambda path: stable_rank(path, args.seed + 1))
    if args.test_dir is None:
        calibration_count = max(
            args.minimum_calibration_volumes,
            int(math.ceil(len(ranked_val) * args.calibration_fraction)),
        )
        calibration_count = min(calibration_count, len(ranked_val) - 1)
        calibration_files = sorted(ranked_val[:calibration_count], key=lambda path: path.name)
        test_files = sorted(ranked_val[calibration_count:], key=lambda path: path.name)
        test_definition = (
            "Held-out subset of official validation volumes with fully sampled references; "
            "not the target-hidden official challenge test set."
        )
    else:
        if not source_test_files:
            raise SystemExit("No test volumes with k-space were found.")
        calibration_files = choose(
            source_val_files,
            args.calibration_use_fraction,
            args.seed + 1,
        )
        test_files = choose(source_test_files, args.test_use_fraction, args.seed + 2)
        test_definition = "Separate fully sampled official test volumes."
    if args.target_calibration_volumes > 0:
        if len(calibration_files) < args.target_calibration_volumes:
            raise SystemExit(
                f"calibration: found {len(calibration_files)} volumes but target is "
                f"{args.target_calibration_volumes}."
            )
        calibration_files = sorted(
            sorted(
                calibration_files,
                key=lambda path: stable_rank(path, args.seed + 3),
            )[: args.target_calibration_volumes],
            key=lambda path: path.name,
        )
    if args.target_test_volumes > 0:
        if len(test_files) < args.target_test_volumes:
            raise SystemExit(
                f"test: found {len(test_files)} volumes but target is "
                f"{args.target_test_volumes}."
            )
        test_files = sorted(
            sorted(test_files, key=lambda path: stable_rank(path, args.seed + 4))[
                : args.target_test_volumes
            ],
            key=lambda path: path.name,
        )

    train_ids = {path.stem for path in selected_train}
    calibration_ids = {path.stem for path in calibration_files}
    test_ids = {path.stem for path in test_files}
    if train_ids & calibration_ids or train_ids & test_ids or calibration_ids & test_ids:
        raise RuntimeError("Volume leakage detected between train, calibration, and test manifests.")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    manifest_specs = [
        ("train_manifest.csv", selected_train, "train", args.train_slices_per_volume),
        (
            "calibration_manifest.csv",
            calibration_files,
            "validation",
            args.calibration_slices_per_volume or args.evaluation_slices_per_volume,
        ),
        (
            "test_manifest.csv",
            test_files,
            "test",
            args.test_slices_per_volume or args.evaluation_slices_per_volume,
        ),
    ]
    hashes = {}
    for filename, files, split, slice_count in manifest_specs:
        path = args.out_dir / filename
        pd.DataFrame(
            manifest_rows(files, split, slice_count, args.dataset_name)
        ).to_csv(path, index=False)
        hashes[filename] = sha256_file(path)

    summary = {
        "dataset_name": args.dataset_name,
        "acquisition": args.acquisition,
        "seed": args.seed,
        "train_fraction": args.train_fraction,
        "calibration_fraction_of_official_validation": args.calibration_fraction,
        "official_train_volumes_found": len(train_files),
        "official_validation_volumes_found": len(source_val_files),
        "selected_train_volumes": len(selected_train),
        "calibration_volumes": len(calibration_files),
        "held_out_test_volumes": len(test_files),
        "train_slices_per_volume": args.train_slices_per_volume,
        "calibration_slices_per_volume": (
            args.calibration_slices_per_volume or args.evaluation_slices_per_volume
        ),
        "test_slices_per_volume": (
            args.test_slices_per_volume or args.evaluation_slices_per_volume
        ),
        "manifest_sha256": hashes,
        "leakage_check": "passed",
        "test_definition": test_definition,
    }
    (args.out_dir / "manifest_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2), flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-name", required=True)
    parser.add_argument("--train-dir", type=Path, required=True)
    parser.add_argument("--source-val-dir", type=Path, required=True)
    parser.add_argument("--test-dir", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--acquisition", default=None)
    parser.add_argument("--train-fraction", type=float, default=0.30)
    parser.add_argument("--calibration-fraction", type=float, default=0.30)
    parser.add_argument("--calibration-use-fraction", type=float, default=1.0)
    parser.add_argument("--test-use-fraction", type=float, default=1.0)
    parser.add_argument("--target-train-volumes", type=int, default=0)
    parser.add_argument("--target-calibration-volumes", type=int, default=0)
    parser.add_argument("--target-test-volumes", type=int, default=0)
    parser.add_argument("--minimum-calibration-volumes", type=int, default=20)
    parser.add_argument("--train-slices-per-volume", type=int, default=8)
    parser.add_argument("--evaluation-slices-per-volume", type=int, default=3)
    parser.add_argument("--calibration-slices-per-volume", type=int, default=0)
    parser.add_argument("--test-slices-per-volume", type=int, default=0)
    parser.add_argument("--expected-train-volumes", type=int, default=0)
    parser.add_argument("--expected-validation-volumes", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260709)
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()
    if not 0 < args.train_fraction <= 1:
        parser.error("--train-fraction must be in (0, 1].")
    if not 0 < args.calibration_fraction < 1:
        parser.error("--calibration-fraction must be in (0, 1).")
    if not 0 < args.calibration_use_fraction <= 1:
        parser.error("--calibration-use-fraction must be in (0, 1].")
    if not 0 < args.test_use_fraction <= 1:
        parser.error("--test-use-fraction must be in (0, 1].")
    return args


if __name__ == "__main__":
    run(parse_args())
