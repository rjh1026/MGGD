"""Add a GRAPPA-style k-space interpolation baseline to a protocol run.

The main protocol uses variable-density Cartesian masks. This implementation
therefore trains an autocalibrated linear k-space kernel for the local sampling
pattern around each missing phase-encode line, using the fully sampled central
calibration region present in the mask.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import run_fastmri_manuscript_protocol as protocol
import run_fastmri_subset_experiment as fmri
import run_synthetic_mggd_experiment as core


Array = np.ndarray


@dataclass(frozen=True)
class GrappaConfig:
    source_lines: int = 4
    readout_half_width: int = 2
    ridge: float = 1e-3
    max_offset: int = 16


def load_cases(run_summary: dict) -> List[protocol.Case]:
    test_manifest = run_summary.get("test_manifest")
    if test_manifest:
        return protocol.cases_from_manifest(Path(test_manifest), "test")
    test_dir = Path(run_summary["test_dir"])
    files = {path.stem: path for path in test_dir.rglob("*.h5")}
    cases: List[protocol.Case] = []
    for case_id in run_summary["test_cases"]:
        stem, slice_text = case_id.rsplit("_slice", 1)
        path = files.get(stem)
        if path is None:
            raise FileNotFoundError(f"Could not resolve test case {case_id} under {test_dir}")
        cases.append(protocol.Case(split="test", path=path, slice_idx=int(slice_text)))
    return cases


def contiguous_acs_rows(mask_1d: Array) -> Tuple[int, int]:
    center = len(mask_1d) // 2
    start = center
    while start > 0 and mask_1d[start - 1]:
        start -= 1
    end = center + 1
    while end < len(mask_1d) and mask_1d[end]:
        end += 1
    return start, end


def nearest_source_offsets(mask_1d: Array, row: int, cfg: GrappaConfig) -> Tuple[int, ...]:
    sampled = np.flatnonzero(mask_1d)
    candidates = sampled[sampled != row]
    candidates = candidates[np.abs(candidates - row) <= cfg.max_offset]
    if candidates.size < 2:
        return tuple()
    order = np.argsort(np.abs(candidates - row))
    selected = candidates[order[: cfg.source_lines]]
    return tuple(int(value - row) for value in sorted(selected))


def fallback_fill_row(kspace: Array, mask_1d: Array, row: int) -> Array:
    sampled = np.flatnonzero(mask_1d)
    lower = sampled[sampled < row]
    upper = sampled[sampled > row]
    if lower.size and upper.size:
        lo = int(lower[-1])
        hi = int(upper[0])
        weight = (row - lo) / max(hi - lo, 1)
        return (1.0 - weight) * kspace[:, lo, :] + weight * kspace[:, hi, :]
    if lower.size:
        return kspace[:, int(lower[-1]), :]
    if upper.size:
        return kspace[:, int(upper[0]), :]
    return np.zeros_like(kspace[:, row, :])


def train_kernel(
    acs: Array,
    offsets: Tuple[int, ...],
    cfg: GrappaConfig,
    cache: Dict[Tuple[int, ...], Array],
) -> Array | None:
    if offsets in cache:
        return cache[offsets]

    coils, height, width = acs.shape
    half = cfg.readout_half_width
    rows = range(max(0, -min(offsets)), min(height, height - max(offsets)))
    cols = range(half, width - half)
    features = coils * len(offsets) * (2 * half + 1)
    if len(list(rows)) * max(width - 2 * half, 0) <= features:
        return None

    x_rows = []
    y_rows = []
    for target_row in rows:
        source_rows = [target_row + offset for offset in offsets]
        if min(source_rows) < 0 or max(source_rows) >= height:
            continue
        for col in cols:
            patch = acs[:, source_rows, col - half : col + half + 1]
            x_rows.append(patch.reshape(-1))
            y_rows.append(acs[:, target_row, col])

    if len(x_rows) <= features:
        return None

    x = np.asarray(x_rows, dtype=np.complex128)
    y = np.asarray(y_rows, dtype=np.complex128)
    gram = x.conj().T @ x
    gram.flat[:: gram.shape[0] + 1] += cfg.ridge
    weights = np.linalg.solve(gram, x.conj().T @ y)
    cache[offsets] = weights
    return weights


def apply_kernel_row(kspace: Array, row: int, offsets: Tuple[int, ...], weights: Array, cfg: GrappaConfig) -> Array:
    coils, _, width = kspace.shape
    half = cfg.readout_half_width
    output = fallback_fill_row(kspace, np.any(np.abs(kspace) > 0, axis=(0, 2)), row)
    source_rows = [row + offset for offset in offsets]
    for col in range(half, width - half):
        patch = kspace[:, source_rows, col - half : col + half + 1].reshape(-1)
        output[:, col] = patch @ weights
    return output


def grappa_reconstruct_kspace(y: Array, mask: Array, cfg: GrappaConfig) -> Array:
    mask_1d = mask[:, 0].astype(bool)
    recon = np.array(y, copy=True)
    acs_start, acs_end = contiguous_acs_rows(mask_1d)
    acs = y[:, acs_start:acs_end, :]
    cache: Dict[Tuple[int, ...], Array] = {}

    for row in np.flatnonzero(~mask_1d):
        offsets = nearest_source_offsets(mask_1d, int(row), cfg)
        if not offsets or min(row + offset for offset in offsets) < 0 or max(row + offset for offset in offsets) >= y.shape[1]:
            recon[:, row, :] = fallback_fill_row(recon, mask_1d, int(row))
            continue
        weights = train_kernel(acs, offsets, cfg, cache)
        if weights is None:
            recon[:, row, :] = fallback_fill_row(recon, mask_1d, int(row))
            continue
        recon[:, row, :] = apply_kernel_row(recon, int(row), offsets, weights, cfg)

    return recon


def combine_coils(coil_images: Array, sens: Array, eps: float = 1e-8) -> Array:
    denom = np.maximum(np.sum(np.abs(sens) ** 2, axis=0), eps)
    return np.sum(np.conj(sens) * coil_images, axis=0) / denom


def save_grappa_figures(out_dir: Path, case: protocol.Case, acceleration: int, truth: Array, recon: Array) -> None:
    case_dir = out_dir / "figures" / case.split / f"{case.case_id}_R{acceleration}"
    case_dir.mkdir(parents=True, exist_ok=True)
    ref = np.abs(truth)
    pred = np.abs(recon)
    err = np.abs(pred - ref)
    vmax = max(float(np.percentile(ref, 99.5)), 1e-6)

    for name, image, cmap, vmin, vmax_local in [
        ("reference.png", ref, "gray", 0, vmax),
        ("GRAPPA_recon.png", pred, "gray", 0, vmax),
        ("GRAPPA_error.png", err, "magma", 0, max(0.35, float(np.percentile(err, 99)))),
    ]:
        fig, ax = plt.subplots(figsize=(4, 4))
        ax.imshow(image, cmap=cmap, vmin=vmin, vmax=vmax_local)
        ax.axis("off")
        fig.tight_layout(pad=0)
        fig.savefig(case_dir / name, dpi=160)
        plt.close(fig)


def run(args: argparse.Namespace) -> None:
    source_run = Path(args.source_run)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    run_summary = json.loads((source_run / "run_summary.json").read_text(encoding="utf-8"))
    cfg_dict = run_summary["config"]
    crop_size = int(cfg_dict["image_size"])
    coils = int(cfg_dict["coils"])
    seed = int(cfg_dict["seed"])
    noise_sigma = float(args.noise_sigma if args.noise_sigma is not None else cfg_dict["noise_sigma"])
    accelerations = args.accelerations or list(run_summary["accelerations"])
    cases = load_cases(run_summary)
    grappa_cfg = GrappaConfig(
        source_lines=args.source_lines,
        readout_half_width=args.readout_half_width,
        ridge=args.ridge,
        max_offset=args.max_offset,
    )

    rows = []
    for case in cases:
        sens, truth, _ = fmri.load_slice_from_h5(case.path, case.slice_idx, crop_size)
        sens = fmri.compress_sensitivity_maps(sens, coils)
        for acceleration in accelerations:
            rng = np.random.default_rng(
                protocol.stable_seed("test", case.path.name, case.slice_idx, acceleration, base=seed)
            )
            mask = core.make_mask(crop_size, acceleration, rng)
            y_clean = core.forward(truth, sens, mask)
            y = core.add_complex_noise(y_clean, mask, noise_sigma, rng)
            print(f"GRAPPA file={case.path.name} slice={case.slice_idx} R={acceleration}", flush=True)
            kspace_hat = grappa_reconstruct_kspace(y, mask, grappa_cfg)
            recon = combine_coils(core.ifft2c(kspace_hat), sens)
            row = {
                "split": "test",
                "file": case.path.name,
                "slice": case.slice_idx,
                "case_id": case.case_id,
                "acquisition": fmri.acquisition_name(case.path),
                "acceleration": acceleration,
                "method": "GRAPPA",
            }
            row.update(core.metrics(recon, truth))
            rows.append(row)
            if args.save_figures:
                save_grappa_figures(out_dir, case, acceleration, truth, recon)

    metrics_df = pd.DataFrame(rows)
    metrics_df.to_csv(out_dir / "grappa_test_metrics.csv", index=False)
    summary_df = protocol.summarize_metrics(metrics_df)
    summary_df.to_csv(out_dir / "grappa_test_metric_summary_by_model.csv", index=False)
    volume_metrics = protocol.aggregate_metrics_by_volume(metrics_df)
    volume_metrics.to_csv(out_dir / "grappa_test_metrics_by_volume.csv", index=False)
    protocol.summarize_metrics(volume_metrics).to_csv(
        out_dir / "grappa_test_metric_summary_by_volume.csv",
        index=False,
    )
    (out_dir / "run_summary.json").write_text(
        json.dumps(
            {
                "source_run": str(source_run),
                "accelerations": accelerations,
                "test_cases": [case.case_id for case in cases],
                "method": "GRAPPA",
                "grappa_config": grappa_cfg.__dict__,
                "noise_sigma": noise_sigma,
                "note": "Autocalibrated k-space interpolation baseline for the same variable-density masks used by the protocol run.",
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(summary_df.to_string(index=False))
    print(f"Saved GRAPPA outputs to {out_dir.resolve()}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-run", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--accelerations", type=int, nargs="+")
    parser.add_argument("--noise-sigma", type=float)
    parser.add_argument("--source-lines", type=int, default=4)
    parser.add_argument("--readout-half-width", type=int, default=2)
    parser.add_argument("--ridge", type=float, default=1e-3)
    parser.add_argument("--max-offset", type=int, default=16)
    parser.add_argument("--save-figures", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
