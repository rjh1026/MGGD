"""Full-scale deep-learning fastMRI benchmark runner.

This runner is meant for full train/validation/test folders, not the compact
local subset. It lazily loads H5 slices from disk, trains the same two benchmark
families used in the local experiment, selects the best checkpoint on
validation structural similarity, and evaluates test metrics.

The script still depends on local data availability. It does not download
fastMRI archives or store signed URLs.
"""

from __future__ import annotations

import argparse
import copy
import json
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List

import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch import nn
from torch.cuda.amp import GradScaler, autocast
from torch.utils.data import DataLoader, Dataset

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import run_fastmri_manuscript_protocol as protocol
import run_fastmri_subset_experiment as fmri
import run_synthetic_mggd_experiment as core
from run_fastmri_deep_benchmarks import (
    ImageUNetBaseline,
    VarNetStyleBaseline,
    c_abs,
    complex_to_channels_np,
)

ROOT_DIR = SCRIPT_DIR.parent
OFFICIAL_FASTMRI_DIR = ROOT_DIR / "external" / "fastMRI_official"
if OFFICIAL_FASTMRI_DIR.exists() and str(OFFICIAL_FASTMRI_DIR) not in sys.path:
    sys.path.insert(0, str(OFFICIAL_FASTMRI_DIR))
try:
    from fastmri.models import Unet as OfficialUnet
    from fastmri.models import VarNet as OfficialVarNet
except ImportError:
    OfficialUnet = None
    OfficialVarNet = None


METHOD_LABELS = {
    "DL_UNet_full": "fastMRI U-Net supervised baseline, full-scale local training",
    "DL_VarNet_full": "End-to-End Variational Network-style supervised unrolled reconstruction, full-scale local training",
}


class OfficialUnetWrapper(nn.Module):
    def __init__(self, chans: int):
        super().__init__()
        if OfficialUnet is None:
            raise RuntimeError("Official fastMRI source is not available.")
        self.model = OfficialUnet(
            in_chans=1,
            out_chans=1,
            chans=chans,
            num_pool_layers=4,
            drop_prob=0.0,
        )

    def forward(self, image):
        return self.model(image)


class OfficialVarNetWrapper(nn.Module):
    def __init__(self, chans: int, cascades: int):
        super().__init__()
        if OfficialVarNet is None:
            raise RuntimeError("Official fastMRI source is not available.")
        self.model = OfficialVarNet(
            num_cascades=cascades,
            sens_chans=8,
            sens_pools=4,
            chans=chans,
            pools=4,
            mask_center=True,
        )

    def forward(self, zero, y, sens, mask):
        del zero, sens
        line_mask = mask[:, :1, :].unsqueeze(1).unsqueeze(-1).to(torch.bool)
        magnitude = self.model(y, line_mask)
        return torch.stack((magnitude, torch.zeros_like(magnitude)), dim=-1)


def build_unet(args):
    if args.official_models:
        return OfficialUnetWrapper(args.unet_chans)
    return ImageUNetBaseline(args.unet_chans)


def build_varnet(args):
    if args.official_models:
        return OfficialVarNetWrapper(args.varnet_chans, args.varnet_cascades)
    return VarNetStyleBaseline(args.varnet_chans, args.varnet_cascades)


@dataclass(frozen=True)
class Case:
    split: str
    path: Path
    slice_idx: int

    @property
    def case_id(self) -> str:
        return f"{self.path.stem}_slice{self.slice_idx}"


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def acquisition_name(path: Path) -> str:
    return fmri.acquisition_name(path)


def has_kspace(path: Path) -> bool:
    try:
        with h5py.File(path, "r") as hf:
            return "kspace" in hf
    except OSError:
        return False


def all_slice_indices(path: Path, max_slices_per_file: int) -> List[int]:
    with h5py.File(path, "r") as hf:
        count = int(hf["kspace"].shape[0])
    if max_slices_per_file and max_slices_per_file > 0:
        return fmri.slice_indices(path, max_slices_per_file)
    return list(range(count))


def build_cases(
    split: str,
    data_dir: Path,
    acquisition: str | None,
    max_files: int,
    max_slices_per_file: int,
) -> List[Case]:
    files = [path for path in sorted(data_dir.rglob("*.h5")) if has_kspace(path)]
    if acquisition:
        files = [path for path in files if acquisition_name(path) == acquisition]
    if max_files and max_files > 0:
        files = files[:max_files]
    cases = []
    for path in files:
        for slice_idx in all_slice_indices(path, max_slices_per_file):
            cases.append(Case(split, path, slice_idx))
    return cases


def build_cases_from_manifest(manifest: Path, split: str) -> List[Case]:
    table = pd.read_csv(manifest)
    required = {"path", "slice_idx"}
    missing = required - set(table.columns)
    if missing:
        raise ValueError(f"{manifest} is missing columns: {sorted(missing)}")
    cases = []
    for row in table.itertuples(index=False):
        path = Path(str(row.path))
        if not path.exists():
            raise FileNotFoundError(f"Manifest data file does not exist: {path}")
        cases.append(Case(split, path, int(row.slice_idx)))
    return cases


def load_sample_arrays(
    case: Case,
    acceleration: int,
    crop_size: int,
    coils: int,
    noise_sigma: float,
    seed: int,
) -> dict:
    sens, truth, _ = fmri.load_slice_from_h5(case.path, case.slice_idx, crop_size)
    sens = fmri.compress_sensitivity_maps(sens, coils)
    rng = np.random.default_rng(protocol.stable_seed(case.split, case.path.name, case.slice_idx, acceleration, base=seed))
    mask = core.make_mask(crop_size, acceleration, rng)
    y_clean = core.forward(truth, sens, mask)
    y = core.add_complex_noise(y_clean, mask, noise_sigma, rng)
    zero_filled = core.adjoint(y, sens, mask)
    return {
        "sens": sens.astype(np.complex64),
        "truth": truth.astype(np.complex64),
        "mask": mask.astype(np.float32),
        "y": y.astype(np.complex64),
        "zero_filled": zero_filled.astype(np.complex64),
    }


class UnetFastMRIDataset(Dataset):
    def __init__(
        self,
        cases: List[Case],
        accelerations: List[int],
        crop_size: int,
        coils: int,
        noise_sigma: float,
        seed: int,
        one_sample_per_volume: bool = False,
    ):
        self.cases = cases
        self.accelerations = accelerations
        self.crop_size = crop_size
        self.coils = coils
        self.noise_sigma = noise_sigma
        self.seed = seed
        self.one_sample_per_volume = one_sample_per_volume
        self.epoch = 0
        self.volume_cases = {}
        for case in cases:
            self.volume_cases.setdefault(case.path, []).append(case)
        self.volume_paths = sorted(self.volume_cases, key=lambda path: path.name)

    def __len__(self) -> int:
        if self.one_sample_per_volume:
            return len(self.volume_paths)
        return len(self.cases) * len(self.accelerations)

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch

    def decode_index(self, index: int) -> tuple[Case, int]:
        if self.one_sample_per_volume:
            path = self.volume_paths[index]
            choices = self.volume_cases[path]
            case_seed = protocol.stable_seed(
                "train-case", path.name, self.epoch, base=self.seed
            )
            acceleration_seed = protocol.stable_seed(
                "train-acceleration", path.name, self.epoch, base=self.seed
            )
            case = choices[case_seed % len(choices)]
            acceleration = self.accelerations[
                acceleration_seed % len(self.accelerations)
            ]
            return case, acceleration
        case = self.cases[index // len(self.accelerations)]
        acceleration = self.accelerations[index % len(self.accelerations)]
        return case, acceleration

    def __getitem__(self, index: int):
        case, acceleration = self.decode_index(index)
        arrays = load_sample_arrays(case, acceleration, self.crop_size, self.coils, self.noise_sigma, self.seed)
        x = np.abs(arrays["zero_filled"]).astype(np.float32)[None, :, :]
        y = np.abs(arrays["truth"]).astype(np.float32)[None, :, :]
        return torch.from_numpy(x), torch.from_numpy(y)


class VarNetFastMRIDataset(UnetFastMRIDataset):
    def __getitem__(self, index: int):
        case, acceleration = self.decode_index(index)
        arrays = load_sample_arrays(case, acceleration, self.crop_size, self.coils, self.noise_sigma, self.seed)
        zero = complex_to_channels_np(arrays["zero_filled"])
        y = complex_to_channels_np(arrays["y"])
        sens = complex_to_channels_np(arrays["sens"])
        mask = arrays["mask"].astype(np.float32)
        target = np.abs(arrays["truth"]).astype(np.float32)[None, :, :]
        return (
            torch.from_numpy(zero),
            torch.from_numpy(y),
            torch.from_numpy(sens),
            torch.from_numpy(mask),
            torch.from_numpy(target),
        )


def unet_val_metrics(model, dataset: UnetFastMRIDataset, device: torch.device, limit: int) -> pd.DataFrame:
    model.eval()
    rows = []
    length = len(dataset) if limit <= 0 else min(limit, len(dataset))
    with torch.no_grad():
        for index in range(length):
            case, acceleration = dataset.decode_index(index)
            arrays = load_sample_arrays(case, acceleration, dataset.crop_size, dataset.coils, dataset.noise_sigma, dataset.seed)
            x = torch.from_numpy(np.abs(arrays["zero_filled"]).astype(np.float32)[None, None, :, :]).to(device)
            pred = model(x).detach().cpu().numpy()[0, 0]
            rows.append(metric_row(case, acceleration, "DL_UNet_full", pred, arrays["truth"]))
    return pd.DataFrame(rows)


def varnet_val_metrics(model, dataset: VarNetFastMRIDataset, device: torch.device, limit: int) -> pd.DataFrame:
    model.eval()
    rows = []
    length = len(dataset) if limit <= 0 else min(limit, len(dataset))
    with torch.no_grad():
        for index in range(length):
            case, acceleration = dataset.decode_index(index)
            arrays = load_sample_arrays(case, acceleration, dataset.crop_size, dataset.coils, dataset.noise_sigma, dataset.seed)
            zero = torch.from_numpy(complex_to_channels_np(arrays["zero_filled"])[None, :, :, :]).to(device)
            y = torch.from_numpy(complex_to_channels_np(arrays["y"])[None, :, :, :, :]).to(device)
            sens = torch.from_numpy(complex_to_channels_np(arrays["sens"])[None, :, :, :, :]).to(device)
            mask = torch.from_numpy(arrays["mask"][None, :, :].astype(np.float32)).to(device)
            recon = model(zero, y, sens, mask).detach().cpu().numpy()[0]
            complex_recon = recon[..., 0] + 1j * recon[..., 1]
            rows.append(metric_row(case, acceleration, "DL_VarNet_full", complex_recon, arrays["truth"]))
    return pd.DataFrame(rows)


def save_deep_test_figures(
    out_dir: Path,
    args: argparse.Namespace,
    device: torch.device,
    test_cases: List[Case],
    unet: nn.Module,
    varnet: nn.Module,
) -> None:
    figure_cases = test_cases
    if args.figure_max_cases and args.figure_max_cases > 0:
        figure_cases = figure_cases[: args.figure_max_cases]
    unet.eval()
    varnet.eval()
    with torch.no_grad():
        for case in figure_cases:
            for acceleration in args.accelerations:
                case_dir = (
                    out_dir
                    / "figures"
                    / case.split
                    / f"{case.case_id}_R{acceleration}"
                )
                expected_files = (
                    "comparison_grid.png",
                    "DL_UNet_full_error.png",
                    "DL_UNet_full_recon.png",
                    "DL_VarNet_full_error.png",
                    "DL_VarNet_full_recon.png",
                    "intermediates.npz",
                    "kspace_log.png",
                    "mask.png",
                    "reference.png",
                    "sensitivity_magnitude.png",
                    "zero_filled.png",
                )
                if args.resume and all(
                    (case_dir / name).is_file()
                    and (case_dir / name).stat().st_size > 0
                    for name in expected_files
                ):
                    print(
                        f"resume=skip complete deep figures {case.case_id} R={acceleration}",
                        flush=True,
                    )
                    continue
                arrays = load_sample_arrays(
                    case,
                    acceleration,
                    args.crop_size,
                    args.coils,
                    args.noise_sigma,
                    args.seed,
                )
                unet_x = torch.from_numpy(
                    np.abs(arrays["zero_filled"]).astype(np.float32)[None, None, :, :]
                ).to(device)
                unet_pred = unet(unet_x).detach().cpu().numpy()[0, 0]

                zero = torch.from_numpy(
                    complex_to_channels_np(arrays["zero_filled"])[None, :, :, :]
                ).to(device)
                y = torch.from_numpy(complex_to_channels_np(arrays["y"])[None, :, :, :, :]).to(device)
                sens = torch.from_numpy(
                    complex_to_channels_np(arrays["sens"])[None, :, :, :, :]
                ).to(device)
                mask = torch.from_numpy(arrays["mask"][None, :, :].astype(np.float32)).to(device)
                varnet_recon = varnet(zero, y, sens, mask).detach().cpu().numpy()[0]
                varnet_pred = varnet_recon[..., 0] + 1j * varnet_recon[..., 1]

                protocol.save_case_figures(
                    out_dir,
                    case,
                    acceleration,
                    arrays["y"],
                    arrays["sens"],
                    arrays["mask"],
                    arrays["truth"],
                    {
                        "DL_UNet_full": unet_pred,
                        "DL_VarNet_full": varnet_pred,
                    },
                )


def metric_row(case: Case, acceleration: int, method: str, recon: np.ndarray, truth: np.ndarray) -> dict:
    row = {
        "split": case.split,
        "file": case.path.name,
        "slice": case.slice_idx,
        "case_id": case.case_id,
        "acquisition": acquisition_name(case.path),
        "acceleration": acceleration,
        "method": method,
    }
    row.update(core.metrics(recon, truth))
    return row


def make_loader(dataset: Dataset, args: argparse.Namespace, shuffle: bool) -> DataLoader:
    return DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=shuffle,
        num_workers=args.num_workers,
        pin_memory=torch.cuda.is_available(),
        drop_last=False,
    )


def load_resume_state(model, optimizer, scaler, path: Path, enabled: bool) -> tuple[int, float, dict, list]:
    if not enabled or not path.exists():
        return 1, -float("inf"), copy.deepcopy(model.state_dict()), []
    state = torch.load(path, map_location=next(model.parameters()).device)
    model.load_state_dict(state["model"])
    optimizer.load_state_dict(state["optimizer"])
    scaler.load_state_dict(state["scaler"])
    print(f"Resuming {path.name} after epoch {state['epoch']}", flush=True)
    return (
        int(state["epoch"]) + 1,
        float(state["best_score"]),
        state["best_state"],
        list(state["history"]),
    )


def save_resume_state(
    path: Path,
    epoch: int,
    model,
    optimizer,
    scaler,
    best_score: float,
    best_state: dict,
    rows: list,
) -> None:
    torch.save(
        {
            "epoch": epoch,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scaler": scaler.state_dict(),
            "best_score": best_score,
            "best_state": best_state,
            "history": rows,
        },
        path,
    )


def trailing_non_improving_epochs(rows: list) -> int:
    if not rows:
        return 0
    scores = [float(row["val_SSIM"]) for row in rows]
    best_index = int(np.argmax(scores))
    return len(scores) - best_index - 1


def train_unet_full(train_dataset, val_dataset, args, device, out_dir: Path) -> tuple[pd.DataFrame, dict]:
    model = build_unet(args).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scaler = GradScaler(enabled=args.amp and device.type == "cuda")
    latest_path = out_dir / "DL_UNet_full_latest.pt"
    start_epoch, best_score, best_state, rows = load_resume_state(
        model, optimizer, scaler, latest_path, args.resume
    )
    non_improving = trailing_non_improving_epochs(rows)
    if args.early_stopping_patience > 0 and non_improving >= args.early_stopping_patience:
        print("resume=skip DL_UNet_full training; early stopping was already reached", flush=True)
        model.load_state_dict(best_state)
        return pd.DataFrame(rows), {
            "best_val_SSIM": best_score,
            "epochs": args.epochs,
            "checkpoint": "DL_UNet_full_best.pt",
        }
    loader = make_loader(train_dataset, args, shuffle=True)
    for epoch in range(start_epoch, args.epochs + 1):
        train_dataset.set_epoch(epoch)
        model.train()
        losses = []
        start = time.time()
        for xb, yb in loader:
            xb = xb.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast(enabled=args.amp and device.type == "cuda"):
                pred = model(xb)
                loss = F.l1_loss(pred, yb) + 0.25 * F.mse_loss(pred, yb)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            losses.append(float(loss.detach().cpu()))
        val_df = unet_val_metrics(model, val_dataset, device, args.val_max_samples)
        score = float(val_df["SSIM"].mean())
        if score > best_score + args.early_stopping_min_delta:
            best_score = score
            best_state = copy.deepcopy(model.state_dict())
            torch.save(best_state, out_dir / "DL_UNet_full_best.pt")
            non_improving = 0
        else:
            non_improving += 1
        rows.append(
            {
                "method": "DL_UNet_full",
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "val_NMSE": float(val_df["NMSE"].mean()),
                "val_PSNR": float(val_df["PSNR"].mean()),
                "val_SSIM": score,
                "seconds": time.time() - start,
            }
        )
        save_resume_state(
            latest_path,
            epoch,
            model,
            optimizer,
            scaler,
            best_score,
            best_state,
            rows,
        )
        print(f"DL_UNet_full epoch={epoch:03d} loss={np.mean(losses):.5f} val_SSIM={score:.4f}", flush=True)
        if args.early_stopping_patience > 0 and non_improving >= args.early_stopping_patience:
            print(f"DL_UNet_full early stopping at epoch {epoch}", flush=True)
            break
    model.load_state_dict(best_state)
    return pd.DataFrame(rows), {"best_val_SSIM": best_score, "epochs": args.epochs, "checkpoint": "DL_UNet_full_best.pt"}


def train_varnet_full(train_dataset, val_dataset, args, device, out_dir: Path) -> tuple[pd.DataFrame, dict]:
    model = build_varnet(args).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scaler = GradScaler(enabled=args.amp and device.type == "cuda")
    latest_path = out_dir / "DL_VarNet_full_latest.pt"
    start_epoch, best_score, best_state, rows = load_resume_state(
        model, optimizer, scaler, latest_path, args.resume
    )
    non_improving = trailing_non_improving_epochs(rows)
    if args.early_stopping_patience > 0 and non_improving >= args.early_stopping_patience:
        print("resume=skip DL_VarNet_full training; early stopping was already reached", flush=True)
        model.load_state_dict(best_state)
        return pd.DataFrame(rows), {
            "best_val_SSIM": best_score,
            "epochs": args.epochs,
            "cascades": args.varnet_cascades,
            "checkpoint": "DL_VarNet_full_best.pt",
        }
    loader = make_loader(train_dataset, args, shuffle=True)
    for epoch in range(start_epoch, args.epochs + 1):
        train_dataset.set_epoch(epoch)
        model.train()
        losses = []
        start = time.time()
        for zero, y, sens, mask, target in loader:
            zero = zero.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)
            sens = sens.to(device, non_blocking=True)
            mask = mask.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast(enabled=args.amp and device.type == "cuda"):
                recon = model(zero, y, sens, mask)
                pred = c_abs(recon)[:, None, :, :]
                loss = F.l1_loss(pred, target) + 0.25 * F.mse_loss(pred, target)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()
            losses.append(float(loss.detach().cpu()))
        val_df = varnet_val_metrics(model, val_dataset, device, args.val_max_samples)
        score = float(val_df["SSIM"].mean())
        if score > best_score + args.early_stopping_min_delta:
            best_score = score
            best_state = copy.deepcopy(model.state_dict())
            torch.save(best_state, out_dir / "DL_VarNet_full_best.pt")
            non_improving = 0
        else:
            non_improving += 1
        rows.append(
            {
                "method": "DL_VarNet_full",
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "val_NMSE": float(val_df["NMSE"].mean()),
                "val_PSNR": float(val_df["PSNR"].mean()),
                "val_SSIM": score,
                "seconds": time.time() - start,
            }
        )
        save_resume_state(
            latest_path,
            epoch,
            model,
            optimizer,
            scaler,
            best_score,
            best_state,
            rows,
        )
        print(f"DL_VarNet_full epoch={epoch:03d} loss={np.mean(losses):.5f} val_SSIM={score:.4f}", flush=True)
        if args.early_stopping_patience > 0 and non_improving >= args.early_stopping_patience:
            print(f"DL_VarNet_full early stopping at epoch {epoch}", flush=True)
            break
    model.load_state_dict(best_state)
    return pd.DataFrame(rows), {
        "best_val_SSIM": best_score,
        "epochs": args.epochs,
        "cascades": args.varnet_cascades,
        "checkpoint": "DL_VarNet_full_best.pt",
    }


def evaluate_full(out_dir: Path, args, device, test_cases: List[Case]) -> None:
    test_unet = UnetFastMRIDataset(test_cases, args.accelerations, args.crop_size, args.coils, args.noise_sigma, args.seed)
    test_varnet = VarNetFastMRIDataset(test_cases, args.accelerations, args.crop_size, args.coils, args.noise_sigma, args.seed)

    unet = build_unet(args).to(device)
    unet.load_state_dict(torch.load(out_dir / "DL_UNet_full_best.pt", map_location=device))
    varnet = build_varnet(args).to(device)
    varnet.load_state_dict(torch.load(out_dir / "DL_VarNet_full_best.pt", map_location=device))

    metrics_path = out_dir / "fullscale_deep_test_metrics.csv"
    expected_rows = len(test_cases) * len(args.accelerations) * 2
    metrics = None
    if args.resume and metrics_path.is_file() and metrics_path.stat().st_size > 0:
        cached_metrics = pd.read_csv(metrics_path)
        required_columns = {
            "split",
            "file",
            "case_id",
            "acceleration",
            "method",
            *protocol.METRICS,
        }
        expected_methods = {"DL_UNet_full", "DL_VarNet_full"}
        if (
            len(cached_metrics) == expected_rows
            and required_columns.issubset(cached_metrics.columns)
            and set(cached_metrics["method"].unique()) == expected_methods
        ):
            metrics = cached_metrics
            print(
                f"resume=skip complete deep test metrics rows={len(metrics)}",
                flush=True,
            )

    if metrics is None:
        unet_metrics = unet_val_metrics(unet, test_unet, device, args.test_max_samples)
        varnet_metrics = varnet_val_metrics(varnet, test_varnet, device, args.test_max_samples)
        metrics = pd.concat([unet_metrics, varnet_metrics], ignore_index=True)
        metrics.to_csv(metrics_path, index=False)
        protocol.summarize_metrics(metrics).to_csv(
            out_dir / "fullscale_deep_test_metric_summary.csv", index=False
        )
        protocol.pairwise_significance(metrics).to_csv(
            out_dir / "fullscale_deep_test_pairwise_significance.csv", index=False
        )
        volume_metrics = (
            metrics.groupby(
                ["split", "file", "acceleration", "method"], as_index=False
            )[protocol.METRICS]
            .mean()
            .rename(columns={"file": "case_id"})
        )
        volume_metrics.to_csv(
            out_dir / "fullscale_deep_test_metrics_by_volume.csv", index=False
        )
        protocol.summarize_metrics(volume_metrics).to_csv(
            out_dir / "fullscale_deep_test_metric_summary_by_volume.csv",
            index=False,
        )
        protocol.pairwise_significance(volume_metrics).to_csv(
            out_dir / "fullscale_deep_test_pairwise_significance_by_volume.csv",
            index=False,
        )
    if args.save_figures:
        save_deep_test_figures(out_dir, args, device, test_cases, unet, varnet)


def preflight(args) -> dict:
    if args.train_manifest:
        train_cases = build_cases_from_manifest(args.train_manifest, "train")
    else:
        train_cases = build_cases(
            "train", args.train_dir, args.acquisition, args.max_files, args.max_slices_per_file
        )
    if args.val_manifest:
        val_cases = build_cases_from_manifest(args.val_manifest, "validation")
    else:
        val_cases = build_cases(
            "validation", args.val_dir, args.acquisition, args.max_files, args.max_slices_per_file
        )
    if args.test_manifest:
        test_cases = build_cases_from_manifest(args.test_manifest, "test")
    else:
        test_cases = build_cases(
            "test", args.test_dir, args.acquisition, args.max_files, args.max_slices_per_file
        )
    summary = {
        "train_dir": str(args.train_dir),
        "val_dir": str(args.val_dir),
        "test_dir": str(args.test_dir),
        "acquisition": args.acquisition,
        "train_cases": len(train_cases),
        "validation_cases": len(val_cases),
        "test_cases": len(test_cases),
        "accelerations": args.accelerations,
        "train_samples": len(train_cases) * len(args.accelerations),
        "train_samples_per_epoch": (
            len({case.path for case in train_cases})
            if args.one_sample_per_volume_per_epoch
            else len(train_cases) * len(args.accelerations)
        ),
        "validation_samples": len(val_cases) * len(args.accelerations),
        "test_samples": len(test_cases) * len(args.accelerations),
        "crop_size": args.crop_size,
        "coils": args.coils,
        "official_models": args.official_models,
        "train_manifest": str(args.train_manifest) if args.train_manifest else None,
        "validation_manifest": str(args.val_manifest) if args.val_manifest else None,
        "test_manifest": str(args.test_manifest) if args.test_manifest else None,
    }
    return {"summary": summary, "train_cases": train_cases, "val_cases": val_cases, "test_cases": test_cases}


def run(args) -> int:
    set_seed(args.seed)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    info = preflight(args)
    (args.out_dir / "fullscale_preflight.json").write_text(json.dumps(info["summary"], indent=2), encoding="utf-8")
    print(json.dumps(info["summary"], indent=2), flush=True)
    if args.preflight_only:
        return 0
    for split_name, cases in [
        ("train", info["train_cases"]),
        ("validation", info["val_cases"]),
        ("test", info["test_cases"]),
    ]:
        if not cases:
            raise SystemExit(f"No {split_name} cases found.")

    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    train_unet = UnetFastMRIDataset(
        info["train_cases"],
        args.accelerations,
        args.crop_size,
        args.coils,
        args.noise_sigma,
        args.seed,
        args.one_sample_per_volume_per_epoch,
    )
    val_unet = UnetFastMRIDataset(
        info["val_cases"], args.accelerations, args.crop_size, args.coils, args.noise_sigma, args.seed
    )
    train_varnet = VarNetFastMRIDataset(
        info["train_cases"],
        args.accelerations,
        args.crop_size,
        args.coils,
        args.noise_sigma,
        args.seed,
        args.one_sample_per_volume_per_epoch,
    )
    val_varnet = VarNetFastMRIDataset(
        info["val_cases"], args.accelerations, args.crop_size, args.coils, args.noise_sigma, args.seed
    )

    unet_history, unet_selected = train_unet_full(train_unet, val_unet, args, device, args.out_dir)
    varnet_history, varnet_selected = train_varnet_full(train_varnet, val_varnet, args, device, args.out_dir)
    pd.concat([unet_history, varnet_history], ignore_index=True).to_csv(
        args.out_dir / "fullscale_deep_validation_history.csv", index=False
    )
    selected = {
        "method_labels": METHOD_LABELS,
        "models": {"DL_UNet_full": unet_selected, "DL_VarNet_full": varnet_selected},
        "preflight": info["summary"],
        "note": "Full-scale over the folders provided to this script. The run is full-scale only if those folders contain the full fastMRI split.",
        "official_fastmri_source": (
            str(OFFICIAL_FASTMRI_DIR) if args.official_models else None
        ),
    }
    (args.out_dir / "fullscale_deep_selected_models.json").write_text(json.dumps(selected, indent=2), encoding="utf-8")
    evaluate_full(args.out_dir, args, device, info["test_cases"])
    print(f"Saved full-scale benchmark outputs to {args.out_dir.resolve()}")
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-dir", type=Path, required=True)
    parser.add_argument("--val-dir", type=Path, required=True)
    parser.add_argument("--test-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--train-manifest", type=Path)
    parser.add_argument("--val-manifest", type=Path)
    parser.add_argument("--test-manifest", type=Path)
    parser.add_argument("--acquisition", default=None)
    parser.add_argument("--accelerations", type=int, nargs="+", default=[2, 4, 6, 8])
    parser.add_argument("--crop-size", type=int, default=96)
    parser.add_argument("--coils", type=int, default=8)
    parser.add_argument("--noise-sigma", type=float, default=0.01)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-6)
    parser.add_argument("--unet-chans", type=int, default=32)
    parser.add_argument("--varnet-chans", type=int, default=16)
    parser.add_argument("--varnet-cascades", type=int, default=6)
    parser.add_argument("--seed", type=int, default=101)
    parser.add_argument("--val-max-samples", type=int, default=0)
    parser.add_argument("--test-max-samples", type=int, default=0)
    parser.add_argument("--max-files", type=int, default=0)
    parser.add_argument("--max-slices-per-file", type=int, default=0)
    parser.add_argument("--amp", action="store_true")
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--official-models", action="store_true")
    parser.add_argument("--save-figures", action="store_true")
    parser.add_argument("--figure-max-cases", type=int, default=0)
    parser.add_argument("--one-sample-per-volume-per-epoch", action="store_true")
    parser.add_argument("--early-stopping-patience", type=int, default=0)
    parser.add_argument("--early-stopping-min-delta", type=float, default=1e-4)
    return parser.parse_args()


def main() -> int:
    return run(parse_args())


if __name__ == "__main__":
    raise SystemExit(main())
