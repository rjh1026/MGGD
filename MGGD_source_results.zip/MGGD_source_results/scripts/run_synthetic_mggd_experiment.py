"""Synthetic engineering validation for multiscale GGD MRI reconstruction.

This script implements a controlled multi-coil Cartesian MRI inverse problem
matching the manuscript's core assumptions:

    y = P F S x + noise

All methods share the same forward operator. The compared reconstructions differ
only in reconstruction-stage regularization.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pywt
from scipy.sparse.linalg import LinearOperator, cg
from skimage.metrics import peak_signal_noise_ratio, structural_similarity


Array = np.ndarray


@dataclass(frozen=True)
class ReconConfig:
    image_size: int = 96
    coils: int = 8
    noise_sigma: float = 0.01
    cg_maxiter: int = 80
    cg_rtol: float = 1e-5
    irls_iters: int = 8
    wavelet: str = "db4"
    wavelet_level: int = 3
    irls_eps: float = 1e-6
    seed: int = 7


@dataclass(frozen=True)
class MethodParams:
    ridge: float = 1e-6
    tikhonov: float = 2e-3
    bending: float = 2e-3
    wavelet_l1: float = 4e-4
    mggd_scale: float = 8e-4
    mggd_p: float = 0.75


def fft2c(x: Array) -> Array:
    return np.fft.fft2(x, norm="ortho")


def ifft2c(x: Array) -> Array:
    return np.fft.ifft2(x, norm="ortho")


def make_complex_phantom(n: int) -> Array:
    yy, xx = np.mgrid[-1:1:complex(n), -1:1:complex(n)]
    phantom = np.zeros((n, n), dtype=float)
    # Modified Shepp-Logan-style ellipses, implemented locally to avoid data-cache writes.
    ellipses = [
        (1.00, 0.00, 0.00, 0.69, 0.92, 0.0),
        (-0.80, 0.00, -0.0184, 0.6624, 0.8740, 0.0),
        (-0.20, 0.22, 0.00, 0.1100, 0.3100, -18.0),
        (-0.20, -0.22, 0.00, 0.1600, 0.4100, 18.0),
        (0.10, 0.00, 0.35, 0.2100, 0.2500, 0.0),
        (0.10, 0.00, 0.10, 0.0460, 0.0460, 0.0),
        (0.10, 0.00, -0.10, 0.0460, 0.0460, 0.0),
        (0.10, -0.08, -0.605, 0.0460, 0.0230, 0.0),
        (0.10, 0.00, -0.605, 0.0230, 0.0230, 0.0),
        (0.10, 0.06, -0.605, 0.0230, 0.0460, 0.0),
    ]
    for amp, x0, y0, a, b, theta_deg in ellipses:
        theta = np.deg2rad(theta_deg)
        x_shift = xx - x0
        y_shift = yy - y0
        x_rot = x_shift * np.cos(theta) + y_shift * np.sin(theta)
        y_rot = -x_shift * np.sin(theta) + y_shift * np.cos(theta)
        phantom[(x_rot / a) ** 2 + (y_rot / b) ** 2 <= 1.0] += amp

    detail = np.zeros_like(phantom)
    detail += 0.18 * np.exp(-((xx + 0.28) ** 2 + (yy - 0.18) ** 2) / 0.008)
    detail += 0.12 * np.exp(-((xx - 0.32) ** 2 + (yy + 0.22) ** 2) / 0.004)
    detail += 0.08 * ((np.sin(28 * xx) > 0) & (np.abs(yy + 0.35) < 0.08))

    magnitude = np.clip(phantom + detail, 0, None)
    magnitude /= magnitude.max()
    phase = 0.35 * np.sin(np.pi * xx) + 0.25 * np.cos(np.pi * yy)
    return magnitude * np.exp(1j * phase)


def make_coil_maps(n: int, coils: int) -> Array:
    yy, xx = np.mgrid[-1:1:complex(n), -1:1:complex(n)]
    maps = []
    for idx in range(coils):
        angle = 2 * np.pi * idx / coils
        cx, cy = 0.65 * np.cos(angle), 0.65 * np.sin(angle)
        mag = 0.25 + np.exp(-((xx - cx) ** 2 + (yy - cy) ** 2) / 0.75)
        phase = np.exp(1j * (0.9 * np.cos(angle) * xx + 0.9 * np.sin(angle) * yy))
        maps.append(mag * phase)

    sens = np.asarray(maps)
    rss = np.sqrt(np.sum(np.abs(sens) ** 2, axis=0))
    return sens / np.maximum(rss, 1e-8)


def make_mask(n: int, acceleration: int, rng: np.random.Generator) -> Array:
    target_lines = max(1, int(round(n / acceleration)))
    center_lines = min(target_lines, max(8, int(round(0.08 * n))))
    center = n // 2
    mask_1d = np.zeros(n, dtype=bool)
    start = center - center_lines // 2
    mask_1d[start : start + center_lines] = True

    remaining = target_lines - int(mask_1d.sum())
    if remaining > 0:
        rows = np.arange(n)
        available = ~mask_1d
        sigma = 0.28 * n
        prob = np.exp(-((rows - center) ** 2) / (2 * sigma**2))
        prob = prob * available
        prob = prob / prob.sum()
        selected = rng.choice(rows, size=remaining, replace=False, p=prob)
        mask_1d[selected] = True

    return np.repeat(mask_1d[:, None], n, axis=1)


def forward(x: Array, sens: Array, mask: Array) -> Array:
    return mask[None, :, :] * fft2c(sens * x[None, :, :])


def adjoint(y: Array, sens: Array, mask: Array) -> Array:
    return np.sum(np.conj(sens) * ifft2c(mask[None, :, :] * y), axis=0)


def add_complex_noise(y: Array, mask: Array, sigma: float, rng: np.random.Generator) -> Array:
    noise = sigma / np.sqrt(2) * (
        rng.standard_normal(y.shape) + 1j * rng.standard_normal(y.shape)
    )
    return y + mask[None, :, :] * noise


def laplacian(x: Array) -> Array:
    return (
        -4 * x
        + np.roll(x, 1, axis=0)
        + np.roll(x, -1, axis=0)
        + np.roll(x, 1, axis=1)
        + np.roll(x, -1, axis=1)
    )


def bending_operator(x: Array) -> Array:
    # Periodic biharmonic surrogate for the bending-energy Hessian.
    return laplacian(laplacian(x))


def coeff_slices_for_shape(shape: Tuple[int, int], wavelet: str, level: int):
    coeffs = pywt.wavedec2(np.zeros(shape), wavelet=wavelet, level=level, mode="periodization")
    _, coeff_slices = pywt.coeffs_to_array(coeffs)
    return coeff_slices


def wavelet_array(x: Array, wavelet: str, level: int) -> Tuple[Array, list]:
    coeffs = pywt.wavedec2(x, wavelet=wavelet, level=level, mode="periodization")
    return pywt.coeffs_to_array(coeffs)


def inverse_wavelet_array(arr: Array, coeff_slices: list, wavelet: str) -> Array:
    coeffs = pywt.array_to_coeffs(arr, coeff_slices, output_format="wavedec2")
    return pywt.waverec2(coeffs, wavelet=wavelet, mode="periodization")


def detail_slices(coeff_slices: list) -> Iterable[Tuple[str, tuple]]:
    for level_idx, detail_dict in enumerate(coeff_slices[1:], start=1):
        for band, slc in detail_dict.items():
            yield f"L{level_idx}_{band}", slc


def estimate_subband_scales(x: Array, cfg: ReconConfig) -> Dict[str, float]:
    arr, coeff_slices = wavelet_array(x, cfg.wavelet, cfg.wavelet_level)
    scales = {}
    for key, slc in detail_slices(coeff_slices):
        vals = np.abs(arr[slc]).ravel()
        sigma = np.median(np.abs(vals - np.median(vals))) / 0.6745
        scales[key] = float(max(sigma, 1e-4))
    return scales


def make_wavelet_weights(
    x: Array,
    cfg: ReconConfig,
    coeff_slices: list,
    mode: str,
    params: MethodParams,
    subband_scales: Dict[str, float],
) -> Array:
    arr, _ = wavelet_array(x, cfg.wavelet, cfg.wavelet_level)
    weights = np.zeros_like(arr, dtype=float)

    for key, slc in detail_slices(coeff_slices):
        coeff_abs2 = np.abs(arr[slc]) ** 2
        if mode == "l1":
            p = 1.0
            lam = params.wavelet_l1
        elif mode == "mggd":
            p = params.mggd_p
            scale = subband_scales[key]
            lam = params.mggd_scale / (scale**p)
        else:
            raise ValueError(f"Unknown wavelet mode: {mode}")

        weights[slc] = lam * (p / 2.0) * (coeff_abs2 + cfg.irls_eps) ** (p / 2.0 - 1.0)

    return weights


def wavelet_quadratic_operator(x: Array, weights: Array, coeff_slices: list, cfg: ReconConfig) -> Array:
    arr, _ = wavelet_array(x, cfg.wavelet, cfg.wavelet_level)
    weighted = weights * arr
    out = inverse_wavelet_array(weighted, coeff_slices, cfg.wavelet)
    return out[: x.shape[0], : x.shape[1]]


def solve_normal(
    rhs: Array,
    sens: Array,
    mask: Array,
    cfg: ReconConfig,
    ridge: float = 0.0,
    tikhonov: float = 0.0,
    bending: float = 0.0,
    wavelet_weights: Array | None = None,
    coeff_slices: list | None = None,
    x0: Array | None = None,
) -> Array:
    shape = rhs.shape
    size = rhs.size

    def matvec(v: Array) -> Array:
        x = v.reshape(shape)
        out = adjoint(forward(x, sens, mask), sens, mask)
        if ridge:
            out = out + ridge * x
        if tikhonov:
            out = out + tikhonov * x
        if bending:
            out = out + bending * bending_operator(x)
        if wavelet_weights is not None:
            assert coeff_slices is not None
            out = out + wavelet_quadratic_operator(x, wavelet_weights, coeff_slices, cfg)
        return out.ravel()

    op = LinearOperator((size, size), matvec=matvec, dtype=np.complex128)
    x0_vec = None if x0 is None else x0.ravel()
    sol, info = cg(op, rhs.ravel(), x0=x0_vec, maxiter=cfg.cg_maxiter, tol=cfg.cg_rtol)
    if info != 0:
        print(f"warning: CG ended with info={info}")
    return sol.reshape(shape)


def reconstruct(
    method: str,
    y: Array,
    sens: Array,
    mask: Array,
    cfg: ReconConfig,
    params: MethodParams,
    subband_scales: Dict[str, float],
) -> Array:
    rhs = adjoint(y, sens, mask)
    coeff_slices = coeff_slices_for_shape(rhs.shape, cfg.wavelet, cfg.wavelet_level)
    x0 = rhs

    if method == "SENSE":
        return solve_normal(rhs, sens, mask, cfg, ridge=params.ridge, x0=x0)

    if method == "Tikhonov":
        return solve_normal(rhs, sens, mask, cfg, ridge=params.ridge, tikhonov=params.tikhonov, x0=x0)

    if method == "BE":
        return solve_normal(rhs, sens, mask, cfg, ridge=params.ridge, bending=params.bending, x0=x0)

    if method in {"WaveletL1", "MGGD"}:
        x = x0
        mode = "l1" if method == "WaveletL1" else "mggd"
        bending = 0.0 if method == "WaveletL1" else params.bending
        for _ in range(cfg.irls_iters):
            weights = make_wavelet_weights(x, cfg, coeff_slices, mode, params, subband_scales)
            x = solve_normal(
                rhs,
                sens,
                mask,
                cfg,
                ridge=params.ridge,
                bending=bending,
                wavelet_weights=weights,
                coeff_slices=coeff_slices,
                x0=x,
            )
        return x

    raise ValueError(f"Unknown method: {method}")


def nmse(x: Array, ref: Array) -> float:
    return float(np.sum((x - ref) ** 2) / np.sum(ref**2))


def metrics(recon: Array, truth: Array) -> Dict[str, float]:
    ref = np.abs(truth)
    pred = np.abs(recon)
    data_range = float(ref.max() - ref.min())
    return {
        "NMSE": nmse(pred, ref),
        "PSNR": float(peak_signal_noise_ratio(ref, pred, data_range=data_range)),
        "SSIM": float(structural_similarity(ref, pred, data_range=data_range)),
    }


def summarize_noise(recons: Dict[str, list[Array]]) -> pd.DataFrame:
    rows = []
    variances = {}
    means = {}
    for method, values in recons.items():
        stack = np.stack(values, axis=0)
        means[method] = np.mean(stack, axis=0)
        variances[method] = np.mean(np.abs(stack - means[method]) ** 2, axis=0)

    sense_var = np.maximum(variances["SENSE"], 1e-12)
    foreground = np.abs(means["SENSE"]) > 0.05 * np.max(np.abs(means["SENSE"]))

    for method in recons:
        var = variances[method]
        snr = np.abs(means[method]) / np.sqrt(np.maximum(var, 1e-12))
        ratio = var / sense_var
        rows.append(
            {
                "method": method,
                "median_variance": float(np.median(var[foreground])),
                "median_snr": float(np.median(snr[foreground])),
                "median_var_ratio_vs_sense": float(np.median(ratio[foreground])),
                "median_geff_ratio_vs_sense": float(np.median(np.sqrt(ratio[foreground]))),
            }
        )
    return pd.DataFrame(rows)


def save_figure(
    truth: Array,
    recon_by_method: Dict[str, Array],
    acceleration: int,
    out_dir: Path,
) -> None:
    methods = list(recon_by_method)
    ref = np.abs(truth)
    fig, axes = plt.subplots(2, len(methods) + 1, figsize=(3.1 * (len(methods) + 1), 6.0))
    axes[0, 0].imshow(ref, cmap="gray", vmin=0, vmax=1)
    axes[0, 0].set_title("Reference")
    axes[1, 0].imshow(np.zeros_like(ref), cmap="magma", vmin=0, vmax=0.35)
    axes[1, 0].set_title("Error")

    for col, method in enumerate(methods, start=1):
        pred = np.abs(recon_by_method[method])
        err = np.abs(pred - ref)
        axes[0, col].imshow(pred, cmap="gray", vmin=0, vmax=1)
        axes[0, col].set_title(method)
        axes[1, col].imshow(err, cmap="magma", vmin=0, vmax=0.35)
        axes[1, col].set_title("|error|")

    for ax in axes.ravel():
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(out_dir / f"recon_R{acceleration}.png", dpi=160)
    plt.close(fig)


def save_noise_figure(noise_recons: Dict[str, list[Array]], acceleration: int, out_dir: Path) -> None:
    methods = list(noise_recons)
    variances = {}
    for method, values in noise_recons.items():
        stack = np.stack(values, axis=0)
        mean = np.mean(stack, axis=0)
        variances[method] = np.mean(np.abs(stack - mean) ** 2, axis=0)

    vmax = np.percentile(variances["SENSE"], 99)
    fig, axes = plt.subplots(1, len(methods), figsize=(3.1 * len(methods), 3.1))
    if len(methods) == 1:
        axes = [axes]
    for ax, method in zip(axes, methods):
        ax.imshow(variances[method], cmap="viridis", vmin=0, vmax=vmax)
        ax.set_title(method)
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(out_dir / f"variance_R{acceleration}.png", dpi=160)
    plt.close(fig)


def run_experiment(args: argparse.Namespace) -> None:
    cfg = ReconConfig(
        image_size=args.image_size,
        noise_sigma=args.noise_sigma,
        irls_iters=args.irls_iters,
        cg_maxiter=args.cg_maxiter,
        seed=args.seed,
    )
    params = MethodParams()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(cfg.seed)
    truth = make_complex_phantom(cfg.image_size)
    sens = make_coil_maps(cfg.image_size, cfg.coils)
    subband_scales = estimate_subband_scales(truth, cfg)

    methods = ["SENSE", "Tikhonov", "BE", "WaveletL1", "MGGD"]
    metric_rows = []
    noise_tables = []

    for acceleration in args.accelerations:
        mask = make_mask(cfg.image_size, acceleration, rng)
        y_clean = forward(truth, sens, mask)
        y = add_complex_noise(y_clean, mask, cfg.noise_sigma, rng)

        recon_by_method = {}
        for method in methods:
            print(f"R={acceleration} method={method}")
            recon = reconstruct(method, y, sens, mask, cfg, params, subband_scales)
            recon_by_method[method] = recon
            row = {"acceleration": acceleration, "method": method}
            row.update(metrics(recon, truth))
            metric_rows.append(row)

        save_figure(truth, recon_by_method, acceleration, out_dir)

        if acceleration in args.noise_accelerations:
            noise_recons = {method: [] for method in methods}
            for rep in range(args.noise_repeats):
                rep_rng = np.random.default_rng(cfg.seed + 1000 * acceleration + rep)
                y_rep = add_complex_noise(y_clean, mask, cfg.noise_sigma, rep_rng)
                for method in methods:
                    noise_recons[method].append(
                        reconstruct(method, y_rep, sens, mask, cfg, params, subband_scales)
                    )
            noise_df = summarize_noise(noise_recons)
            noise_df.insert(0, "acceleration", acceleration)
            noise_tables.append(noise_df)
            save_noise_figure(noise_recons, acceleration, out_dir)

    metrics_df = pd.DataFrame(metric_rows)
    metrics_df.to_csv(out_dir / "metrics.csv", index=False)

    if noise_tables:
        noise_df = pd.concat(noise_tables, ignore_index=True)
        noise_df.to_csv(out_dir / "noise_summary.csv", index=False)
    else:
        noise_df = pd.DataFrame()

    summary = {
        "config": cfg.__dict__,
        "method_params": params.__dict__,
        "subband_scales": subband_scales,
        "metrics": metrics_df.to_dict(orient="records"),
        "noise_summary": noise_df.to_dict(orient="records"),
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\n=== Fidelity metrics ===")
    print(metrics_df.to_string(index=False))
    if not noise_df.empty:
        print("\n=== Noise summary ===")
        print(noise_df.to_string(index=False))
    print(f"\nSaved outputs to {out_dir.resolve()}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", default="outputs/synthetic_mggd")
    parser.add_argument("--image-size", type=int, default=96)
    parser.add_argument("--noise-sigma", type=float, default=0.01)
    parser.add_argument("--irls-iters", type=int, default=8)
    parser.add_argument("--cg-maxiter", type=int, default=80)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--accelerations", type=int, nargs="+", default=[2, 4, 6, 8])
    parser.add_argument("--noise-accelerations", type=int, nargs="+", default=[4, 8])
    parser.add_argument("--noise-repeats", type=int, default=6)
    return parser.parse_args()


if __name__ == "__main__":
    run_experiment(parse_args())
