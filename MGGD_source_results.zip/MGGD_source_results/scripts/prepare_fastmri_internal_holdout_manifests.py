"""Create deterministic, volume-disjoint manifests from one fastMRI train pool.

This is an interim design for cases where official validation and test data are
not locally available. Results from these manifests must be reported as an
internal holdout analysis, not as official fastMRI validation or test results.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from prepare_fastmri_30pct_manifests import (
    discover,
    manifest_rows,
    sha256_file,
    stable_rank,
)


def write_manifest(
    out_dir: Path,
    filename: str,
    files: list[Path],
    split: str,
    slices_per_volume: int,
    dataset_name: str,
) -> tuple[int, str]:
    path = out_dir / filename
    rows = manifest_rows(files, split, slices_per_volume, dataset_name)
    pd.DataFrame(rows).to_csv(path, index=False)
    return len(rows), sha256_file(path)


def run(args: argparse.Namespace) -> None:
    pool_files = discover(args.pool_dir, args.acquisition)
    requested = (
        args.train_volumes + args.calibration_volumes + args.test_volumes
    )
    if len(pool_files) != requested:
        raise SystemExit(
            f"Found {len(pool_files)} usable volumes but the requested split "
            f"requires exactly {requested}. Refusing to silently omit or reuse volumes."
        )

    resolved_paths = [str(path.resolve()) for path in pool_files]
    if len(resolved_paths) != len(set(resolved_paths)):
        raise RuntimeError("Duplicate HDF5 paths were discovered in the source pool.")
    volume_ids = [path.stem for path in pool_files]
    if len(volume_ids) != len(set(volume_ids)):
        raise RuntimeError(
            "Duplicate volume identifiers were discovered; leakage cannot be ruled out."
        )

    ranked = sorted(pool_files, key=lambda path: stable_rank(path, args.seed))
    train_end = args.train_volumes
    calibration_end = train_end + args.calibration_volumes
    train_files = sorted(ranked[:train_end], key=lambda path: path.name)
    calibration_files = sorted(
        ranked[train_end:calibration_end],
        key=lambda path: path.name,
    )
    test_files = sorted(ranked[calibration_end:], key=lambda path: path.name)

    train_paths = {str(path.resolve()) for path in train_files}
    calibration_paths = {str(path.resolve()) for path in calibration_files}
    test_paths = {str(path.resolve()) for path in test_files}
    if (
        train_paths & calibration_paths
        or train_paths & test_paths
        or calibration_paths & test_paths
    ):
        raise RuntimeError("Volume leakage detected between internal data splits.")
    if train_paths | calibration_paths | test_paths != set(resolved_paths):
        raise RuntimeError("The internal split does not account for every source volume.")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    row_counts: dict[str, int] = {}
    hashes: dict[str, str] = {}
    specifications = [
        (
            "train_manifest.csv",
            train_files,
            "train",
            args.train_slices_per_volume,
        ),
        (
            "calibration_manifest.csv",
            calibration_files,
            "validation",
            args.calibration_slices_per_volume,
        ),
        (
            "test_manifest.csv",
            test_files,
            "test",
            args.test_slices_per_volume,
        ),
    ]
    for filename, files, split, slices_per_volume in specifications:
        row_count, digest = write_manifest(
            args.out_dir,
            filename,
            files,
            split,
            slices_per_volume,
            args.dataset_name,
        )
        row_counts[filename] = row_count
        hashes[filename] = digest

    summary = {
        "dataset_name": args.dataset_name,
        "acquisition": args.acquisition,
        "seed": args.seed,
        "source_partition": "official_fastmri_train_only",
        "evaluation_design": "internal_volume_holdout",
        "official_validation_used": False,
        "official_test_used": False,
        "partial_archive_used": False,
        "publication_status": (
            "interim_supporting_analysis_not_final_official_split"
        ),
        "reporting_label": (
            "Internal volume-disjoint holdout from collected fastMRI brain "
            "training data"
        ),
        "source_volumes_found": len(pool_files),
        "source_volumes_used": requested,
        "excluded_source_volumes": len(pool_files) - requested,
        "selected_train_volumes": len(train_files),
        "calibration_volumes": len(calibration_files),
        "held_out_test_volumes": len(test_files),
        "train_slices_per_volume": args.train_slices_per_volume,
        "calibration_slices_per_volume": args.calibration_slices_per_volume,
        "test_slices_per_volume": args.test_slices_per_volume,
        "manifest_rows": row_counts,
        "manifest_sha256": hashes,
        "leakage_check": "passed",
        "all_source_volumes_accounted_for": True,
        "limitations": [
            "All three partitions originate from the official fastMRI training split.",
            "This analysis cannot replace evaluation on the official validation/test split.",
            "The incomplete batch_9 archive is preserved but excluded from this analysis.",
        ],
    }
    summary_path = args.out_dir / "manifest_summary.json"
    summary_path.write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2), flush=True)


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("value must be a positive integer")
    return parsed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-name", required=True)
    parser.add_argument("--pool-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--acquisition", default=None)
    parser.add_argument("--train-volumes", type=positive_int, default=505)
    parser.add_argument("--calibration-volumes", type=positive_int, default=20)
    parser.add_argument("--test-volumes", type=positive_int, default=30)
    parser.add_argument("--train-slices-per-volume", type=positive_int, default=8)
    parser.add_argument(
        "--calibration-slices-per-volume",
        type=positive_int,
        default=1,
    )
    parser.add_argument("--test-slices-per-volume", type=positive_int, default=3)
    parser.add_argument("--seed", type=int, default=20260709)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
