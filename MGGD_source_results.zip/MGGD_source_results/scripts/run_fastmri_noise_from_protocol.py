"""Run noise propagation only from an existing manuscript protocol run."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List

import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import run_fastmri_manuscript_protocol as protocol
import run_synthetic_mggd_experiment as core


def load_cases(run_summary: dict) -> List[protocol.Case]:
    test_dir = Path(run_summary["test_dir"])
    files = {path.stem: path for path in test_dir.rglob("*.h5")}
    cases: List[protocol.Case] = []
    for case_id in run_summary["test_cases"]:
        stem, slice_text = case_id.rsplit("_slice", 1)
        path = files.get(stem)
        if path is None:
            raise FileNotFoundError(f"Could not resolve test case {case_id} under {test_dir}")
        cases.append(protocol.Case(split="test", path=path, slice_idx=int(slice_text)))
    return cases


def subset_cases(cases: List[protocol.Case], max_cases: int) -> List[protocol.Case]:
    if max_cases <= 0 or max_cases >= len(cases):
        return cases
    return cases[:max_cases]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--accelerations", type=int, nargs="+", default=[8])
    parser.add_argument("--methods", nargs="+", default=protocol.METHODS)
    parser.add_argument("--noise-repeats", type=int, default=5)
    parser.add_argument("--noise-sigma", type=float, default=0.01)
    parser.add_argument("--max-cases", type=int, default=2)
    args = parser.parse_args()

    run_summary = json.loads((args.run_dir / "run_summary.json").read_text(encoding="utf-8"))
    prior: Dict[str, Dict[str, float]] = json.loads((args.run_dir / "trained_prior.json").read_text(encoding="utf-8"))
    selected = json.loads((args.run_dir / "selected_params.json").read_text(encoding="utf-8"))

    cfg_dict = dict(run_summary["config"])
    cfg_dict["noise_sigma"] = args.noise_sigma
    cfg = core.ReconConfig(**cfg_dict)
    cases = subset_cases(load_cases(run_summary), args.max_cases)
    methods = [method for method in args.methods if method in selected]

    args.out_dir.mkdir(parents=True, exist_ok=True)
    metrics_df, noise_df = protocol.run_reconstruction_set(
        split="test_noise",
        cases=cases,
        cfg=cfg,
        prior=prior,
        params_by_method=selected,
        accelerations=args.accelerations,
        crop_size=int(cfg.image_size),
        coils=int(cfg.coils),
        noise_sigma=args.noise_sigma,
        seed=int(cfg.seed),
        methods=methods,
        out_dir=args.out_dir,
        save_figures=True,
        noise_repeats=args.noise_repeats,
    )

    metrics_df.to_csv(args.out_dir / "test_noise_metrics.csv", index=False)
    noise_df.to_csv(args.out_dir / "test_noise_summary.csv", index=False)
    protocol.summarize_metrics(metrics_df).to_csv(args.out_dir / "test_noise_metric_summary_by_model.csv", index=False)
    if not metrics_df.empty:
        protocol.pairwise_significance(metrics_df).to_csv(
            args.out_dir / "test_noise_pairwise_significance_all_pairs.csv", index=False
        )

    noise_run_summary = {
        "source_run_dir": str(args.run_dir),
        "test_cases": [case.case_id for case in cases],
        "accelerations": args.accelerations,
        "methods": methods,
        "noise_repeats": args.noise_repeats,
        "noise_sigma": args.noise_sigma,
        "config": cfg.__dict__,
    }
    (args.out_dir / "run_summary.json").write_text(json.dumps(noise_run_summary, indent=2), encoding="utf-8")
    print(noise_df.to_string(index=False))
    print(f"Saved noise outputs to {args.out_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
