"""Train and evaluate compact deep-learning MRI reconstruction benchmarks.

The official fastMRI package/checkpoints are not assumed to be installed. This
script implements two manuscript-facing benchmark families on the exact split
used by the local protocol runs:

1. fastMRI U-Net supervised image-domain baseline.
2. Variational Network-style supervised unrolled reconstruction with explicit
   multi-coil forward-model data consistency.

Both are intentionally small so the benchmark is reproducible on the available
subset while keeping train/validation/test separation intact.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import random
import sys
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import run_fastmri_manuscript_protocol as protocol
import run_fastmri_subset_experiment as fmri
import run_synthetic_mggd_experiment as core


METHODS = ["DL_UNet", "DL_VarNet"]
METHOD_LABELS = {
    "DL_UNet": "fastMRI U-Net supervised baseline",
    "DL_VarNet": "End-to-End Variational Network-style supervised unrolled reconstruction",
}


@dataclass
class Sample:
    split: str
    file: str
    path: Path
    slice_idx: int
    case_id: str
    acceleration: int
    zero_filled: np.ndarray
    y: np.ndarray
    sens: np.ndarray
    mask: np.ndarray
    truth: np.ndarray
    kspace: np.ndarray


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_cases(run_summary: dict, split_key: str, dir_key: str, split_name: str) -> List[protocol.Case]:
    data_dir = Path(run_summary[dir_key])
    files = {path.stem: path for path in data_dir.rglob("*.h5")}
    cases = []
    for case_id in run_summary[split_key]:
        stem, slice_text = case_id.rsplit("_slice", 1)
        path = files.get(stem)
        if path is None:
            raise FileNotFoundError(f"Could not resolve {case_id} under {data_dir}")
        cases.append(protocol.Case(split=split_name, path=path, slice_idx=int(slice_text)))
    return cases


def prepare_samples(
    cases: Iterable[protocol.Case],
    split_name: str,
    cfg: core.ReconConfig,
    accelerations: List[int],
    crop_size: int,
    coils: int,
    noise_sigma: float,
    seed: int,
) -> List[Sample]:
    samples: List[Sample] = []
    for case in cases:
        kspace = protocol.read_cropped_kspace(case.path, case.slice_idx, crop_size)
        sens, truth, _ = fmri.load_slice_from_h5(case.path, case.slice_idx, crop_size)
        if coils and sens.shape[0] > coils:
            sens = sens[:coils]
            kspace = kspace[:coils] if kspace.ndim == 3 else kspace
        for acceleration in accelerations:
            rng = np.random.default_rng(
                protocol.stable_seed(split_name, case.path.name, case.slice_idx, acceleration, base=seed)
            )
            mask = core.make_mask(crop_size, acceleration, rng)
            y_clean = core.forward(truth, sens, mask)
            y = core.add_complex_noise(y_clean, mask, noise_sigma, rng)
            zero_filled = core.adjoint(y, sens, mask)
            samples.append(
                Sample(
                    split=split_name,
                    file=case.path.name,
                    path=case.path,
                    slice_idx=case.slice_idx,
                    case_id=case.case_id,
                    acceleration=acceleration,
                    zero_filled=zero_filled.astype(np.complex64),
                    y=y.astype(np.complex64),
                    sens=sens.astype(np.complex64),
                    mask=mask.astype(np.float32),
                    truth=truth.astype(np.complex64),
                    kspace=np.asarray(kspace),
                )
            )
    return samples


def complex_to_channels_np(x: np.ndarray) -> np.ndarray:
    return np.stack([np.real(x), np.imag(x)], axis=-1).astype(np.float32)


def samples_to_unet_tensors(samples: List[Sample]) -> Tuple[torch.Tensor, torch.Tensor]:
    inputs = [np.abs(sample.zero_filled).astype(np.float32)[None, :, :] for sample in samples]
    targets = [np.abs(sample.truth).astype(np.float32)[None, :, :] for sample in samples]
    return torch.from_numpy(np.stack(inputs)), torch.from_numpy(np.stack(targets))


def samples_to_varnet_tensors(samples: List[Sample]) -> Tuple[torch.Tensor, ...]:
    zero = [complex_to_channels_np(sample.zero_filled) for sample in samples]
    y = [complex_to_channels_np(sample.y) for sample in samples]
    sens = [complex_to_channels_np(sample.sens) for sample in samples]
    masks = [sample.mask.astype(np.float32) for sample in samples]
    targets = [np.abs(sample.truth).astype(np.float32)[None, :, :] for sample in samples]
    return (
        torch.from_numpy(np.stack(zero)),
        torch.from_numpy(np.stack(y)),
        torch.from_numpy(np.stack(sens)),
        torch.from_numpy(np.stack(masks)),
        torch.from_numpy(np.stack(targets)),
    )


class ConvBlock(nn.Module):
    def __init__(self, in_chans: int, out_chans: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_chans, out_chans, 3, padding=1),
            nn.InstanceNorm2d(out_chans, affine=True),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(out_chans, out_chans, 3, padding=1),
            nn.InstanceNorm2d(out_chans, affine=True),
            nn.LeakyReLU(0.1, inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class SmallUNet(nn.Module):
    def __init__(self, in_chans: int = 1, out_chans: int = 1, chans: int = 16):
        super().__init__()
        self.down1 = ConvBlock(in_chans, chans)
        self.down2 = ConvBlock(chans, chans * 2)
        self.down3 = ConvBlock(chans * 2, chans * 4)
        self.pool = nn.MaxPool2d(2)
        self.up2 = nn.ConvTranspose2d(chans * 4, chans * 2, 2, stride=2)
        self.conv2 = ConvBlock(chans * 4, chans * 2)
        self.up1 = nn.ConvTranspose2d(chans * 2, chans, 2, stride=2)
        self.conv1 = ConvBlock(chans * 2, chans)
        self.final = nn.Conv2d(chans, out_chans, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        d1 = self.down1(x)
        d2 = self.down2(self.pool(d1))
        bottleneck = self.down3(self.pool(d2))
        u2 = self.up2(bottleneck)
        u2 = torch.cat([u2, d2], dim=1)
        u2 = self.conv2(u2)
        u1 = self.up1(u2)
        u1 = torch.cat([u1, d1], dim=1)
        u1 = self.conv1(u1)
        return self.final(u1)


class ImageUNetBaseline(nn.Module):
    def __init__(self, chans: int):
        super().__init__()
        self.unet = SmallUNet(1, 1, chans)

    def forward(self, zero_mag: torch.Tensor) -> torch.Tensor:
        return F.relu(zero_mag + self.unet(zero_mag))


def c_mul(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    real = a[..., 0] * b[..., 0] - a[..., 1] * b[..., 1]
    imag = a[..., 0] * b[..., 1] + a[..., 1] * b[..., 0]
    return torch.stack([real, imag], dim=-1)


def c_conj(a: torch.Tensor) -> torch.Tensor:
    return torch.stack([a[..., 0], -a[..., 1]], dim=-1)


def c_abs(a: torch.Tensor) -> torch.Tensor:
    return torch.sqrt(torch.clamp(a[..., 0] ** 2 + a[..., 1] ** 2, min=1e-12))


def complex_to_chan_torch(x: torch.Tensor) -> torch.Tensor:
    return x.permute(0, 3, 1, 2).contiguous()


def chan_to_complex_torch(x: torch.Tensor) -> torch.Tensor:
    return x.permute(0, 2, 3, 1).contiguous()


def fft2_old(x: torch.Tensor) -> torch.Tensor:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return torch.fft(x, 2, normalized=True)


def ifft2_old(x: torch.Tensor) -> torch.Tensor:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return torch.ifft(x, 2, normalized=True)


def forward_torch(x: torch.Tensor, sens: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    coil_images = c_mul(sens, x[:, None, :, :, :])
    kspace = fft2_old(coil_images)
    return kspace * mask[:, None, :, :, None]


def adjoint_torch(y: torch.Tensor, sens: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    coil_images = ifft2_old(y * mask[:, None, :, :, None])
    return c_mul(c_conj(sens), coil_images).sum(dim=1)


class VarNetCascade(nn.Module):
    def __init__(self, chans: int):
        super().__init__()
        self.regularizer = SmallUNet(2, 2, chans)
        self.dc_log_weight = nn.Parameter(torch.tensor(-2.0))
        self.reg_log_weight = nn.Parameter(torch.tensor(-2.0))

    def forward(self, x: torch.Tensor, y: torch.Tensor, sens: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        data_residual = forward_torch(x, sens, mask) - y
        dc_grad = adjoint_torch(data_residual, sens, mask)
        reg = chan_to_complex_torch(self.regularizer(complex_to_chan_torch(x)))
        return x - F.softplus(self.dc_log_weight) * dc_grad - F.softplus(self.reg_log_weight) * reg


class VarNetStyleBaseline(nn.Module):
    def __init__(self, chans: int, cascades: int):
        super().__init__()
        self.cascades = nn.ModuleList([VarNetCascade(chans) for _ in range(cascades)])

    def forward(self, zero: torch.Tensor, y: torch.Tensor, sens: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        x = zero
        for cascade in self.cascades:
            x = cascade(x, y, sens, mask)
        return x


def train_unet(
    train_samples: List[Sample],
    val_samples: List[Sample],
    args: argparse.Namespace,
    device: torch.device,
    out_dir: Path,
) -> Tuple[ImageUNetBaseline, pd.DataFrame, dict]:
    x_train, y_train = samples_to_unet_tensors(train_samples)
    x_val, y_val = samples_to_unet_tensors(val_samples)
    loader = DataLoader(TensorDataset(x_train, y_train), batch_size=args.batch_size, shuffle=True)
    model = ImageUNetBaseline(args.unet_chans).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    best_state = copy.deepcopy(model.state_dict())
    best_score = -float("inf")
    rows = []

    for epoch in range(1, args.epochs + 1):
        model.train()
        losses = []
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            pred = model(xb)
            loss = F.l1_loss(pred, yb) + 0.25 * F.mse_loss(pred, yb)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        val_metrics = evaluate_unet(model, val_samples, device)
        score = float(val_metrics["SSIM"].mean())
        rows.append(
            {
                "method": "DL_UNet",
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "val_NMSE": float(val_metrics["NMSE"].mean()),
                "val_PSNR": float(val_metrics["PSNR"].mean()),
                "val_SSIM": score,
            }
        )
        if score > best_score:
            best_score = score
            best_state = copy.deepcopy(model.state_dict())
        if epoch == 1 or epoch % args.log_every == 0 or epoch == args.epochs:
            print(
                f"DL_UNet epoch={epoch:03d} train_loss={np.mean(losses):.5f} "
                f"val_SSIM={score:.4f}",
                flush=True,
            )

    model.load_state_dict(best_state)
    torch.save(best_state, out_dir / "DL_UNet_best.pt")
    selected = {"best_val_SSIM": best_score, "epochs": args.epochs}
    return model, pd.DataFrame(rows), selected


def train_varnet(
    train_samples: List[Sample],
    val_samples: List[Sample],
    args: argparse.Namespace,
    device: torch.device,
    out_dir: Path,
) -> Tuple[VarNetStyleBaseline, pd.DataFrame, dict]:
    tensors = samples_to_varnet_tensors(train_samples)
    loader = DataLoader(TensorDataset(*tensors), batch_size=args.batch_size, shuffle=True)
    model = VarNetStyleBaseline(args.varnet_chans, args.varnet_cascades).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    best_state = copy.deepcopy(model.state_dict())
    best_score = -float("inf")
    rows = []

    for epoch in range(1, args.epochs + 1):
        model.train()
        losses = []
        for zero, y, sens, mask, target in loader:
            zero = zero.to(device)
            y = y.to(device)
            sens = sens.to(device)
            mask = mask.to(device)
            target = target.to(device)
            recon = model(zero, y, sens, mask)
            pred = c_abs(recon)[:, None, :, :]
            loss = F.l1_loss(pred, target) + 0.25 * F.mse_loss(pred, target)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        val_metrics = evaluate_varnet(model, val_samples, device)
        score = float(val_metrics["SSIM"].mean())
        rows.append(
            {
                "method": "DL_VarNet",
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "val_NMSE": float(val_metrics["NMSE"].mean()),
                "val_PSNR": float(val_metrics["PSNR"].mean()),
                "val_SSIM": score,
            }
        )
        if score > best_score:
            best_score = score
            best_state = copy.deepcopy(model.state_dict())
        if epoch == 1 or epoch % args.log_every == 0 or epoch == args.epochs:
            print(
                f"DL_VarNet epoch={epoch:03d} train_loss={np.mean(losses):.5f} "
                f"val_SSIM={score:.4f}",
                flush=True,
            )

    model.load_state_dict(best_state)
    torch.save(best_state, out_dir / "DL_VarNet_best.pt")
    selected = {
        "best_val_SSIM": best_score,
        "epochs": args.epochs,
        "cascades": args.varnet_cascades,
    }
    return model, pd.DataFrame(rows), selected


def evaluate_unet(model: ImageUNetBaseline, samples: List[Sample], device: torch.device) -> pd.DataFrame:
    rows = []
    model.eval()
    with torch.no_grad():
        for sample in samples:
            x = torch.from_numpy(np.abs(sample.zero_filled).astype(np.float32)[None, None, :, :]).to(device)
            pred = model(x).detach().cpu().numpy()[0, 0]
            recon = pred.astype(np.float32)
            row = sample_metric_row(sample, "DL_UNet", recon)
            rows.append(row)
    return pd.DataFrame(rows)


def evaluate_varnet(model: VarNetStyleBaseline, samples: List[Sample], device: torch.device) -> pd.DataFrame:
    rows = []
    model.eval()
    with torch.no_grad():
        for sample in samples:
            zero = torch.from_numpy(complex_to_channels_np(sample.zero_filled)[None, :, :, :]).to(device)
            y = torch.from_numpy(complex_to_channels_np(sample.y)[None, :, :, :, :]).to(device)
            sens = torch.from_numpy(complex_to_channels_np(sample.sens)[None, :, :, :, :]).to(device)
            mask = torch.from_numpy(sample.mask[None, :, :].astype(np.float32)).to(device)
            recon = model(zero, y, sens, mask).detach().cpu().numpy()[0]
            complex_recon = recon[..., 0] + 1j * recon[..., 1]
            row = sample_metric_row(sample, "DL_VarNet", complex_recon)
            rows.append(row)
    return pd.DataFrame(rows)


def sample_metric_row(sample: Sample, method: str, recon: np.ndarray) -> dict:
    row = {
        "split": sample.split,
        "file": sample.file,
        "slice": sample.slice_idx,
        "case_id": sample.case_id,
        "acquisition": fmri.acquisition_name(sample.path),
        "acceleration": sample.acceleration,
        "method": method,
    }
    row.update(core.metrics(recon, sample.truth))
    return row


def save_deep_figures(
    out_dir: Path,
    samples: List[Sample],
    unet: ImageUNetBaseline,
    varnet: VarNetStyleBaseline,
    device: torch.device,
    max_figures: int,
) -> None:
    unet.eval()
    varnet.eval()
    with torch.no_grad():
        for sample in samples[:max_figures]:
            x = torch.from_numpy(np.abs(sample.zero_filled).astype(np.float32)[None, None, :, :]).to(device)
            unet_recon = unet(x).detach().cpu().numpy()[0, 0]

            zero = torch.from_numpy(complex_to_channels_np(sample.zero_filled)[None, :, :, :]).to(device)
            y = torch.from_numpy(complex_to_channels_np(sample.y)[None, :, :, :, :]).to(device)
            sens = torch.from_numpy(complex_to_channels_np(sample.sens)[None, :, :, :, :]).to(device)
            mask = torch.from_numpy(sample.mask[None, :, :].astype(np.float32)).to(device)
            varnet_recon = varnet(zero, y, sens, mask).detach().cpu().numpy()[0]
            varnet_complex = varnet_recon[..., 0] + 1j * varnet_recon[..., 1]

            recon_by_method = {
                "fastMRI_U_Net": unet_recon,
                "VarNet_style": varnet_complex,
            }
            protocol.save_case_figures(
                out_dir,
                protocol.Case(split=sample.split, path=sample.path, slice_idx=sample.slice_idx),
                sample.acceleration,
                sample.kspace,
                sample.sens,
                sample.mask,
                sample.truth,
                recon_by_method,
            )


def run_from_summary(args: argparse.Namespace) -> int:
    set_seed(args.seed)
    run_summary = json.loads(args.run_dir.joinpath("run_summary.json").read_text(encoding="utf-8"))
    cfg_dict = dict(run_summary["config"])
    cfg = core.ReconConfig(**cfg_dict)
    accelerations = [int(acc) for acc in run_summary["accelerations"]]

    train_cases = resolve_cases(run_summary, "train_cases", "train_dir", "train")
    val_cases = resolve_cases(run_summary, "validation_cases", "val_dir", "validation")
    test_cases = resolve_cases(run_summary, "test_cases", "test_dir", "test")

    train_samples = prepare_samples(
        train_cases,
        "train",
        cfg,
        accelerations,
        int(cfg.image_size),
        int(cfg.coils),
        float(cfg.noise_sigma),
        int(cfg.seed),
    )
    val_samples = prepare_samples(
        val_cases,
        "validation",
        cfg,
        accelerations,
        int(cfg.image_size),
        int(cfg.coils),
        float(cfg.noise_sigma),
        int(cfg.seed),
    )
    test_samples = prepare_samples(
        test_cases,
        "test",
        cfg,
        accelerations,
        int(cfg.image_size),
        int(cfg.coils),
        float(cfg.noise_sigma),
        int(cfg.seed),
    )

    args.out_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    print(f"device={device} train={len(train_samples)} validation={len(val_samples)} test={len(test_samples)}")

    unet, unet_history, unet_selected = train_unet(train_samples, val_samples, args, device, args.out_dir)
    varnet, varnet_history, varnet_selected = train_varnet(train_samples, val_samples, args, device, args.out_dir)

    history = pd.concat([unet_history, varnet_history], ignore_index=True)
    history.to_csv(args.out_dir / "deep_validation_history.csv", index=False)

    test_metrics = pd.concat(
        [
            evaluate_unet(unet, test_samples, device),
            evaluate_varnet(varnet, test_samples, device),
        ],
        ignore_index=True,
    )
    test_metrics.to_csv(args.out_dir / "deep_test_metrics.csv", index=False)
    protocol.summarize_metrics(test_metrics).to_csv(args.out_dir / "deep_test_metric_summary.csv", index=False)
    protocol.pairwise_significance(test_metrics).to_csv(args.out_dir / "deep_test_pairwise_significance.csv", index=False)

    save_deep_figures(args.out_dir, test_samples, unet, varnet, device, args.max_figures)

    selected = {
        "dataset_name": run_summary.get("dataset_name", ""),
        "source_run_dir": str(args.run_dir),
        "models": {
            "DL_UNet": unet_selected,
            "DL_VarNet": varnet_selected,
        },
        "method_labels": METHOD_LABELS,
        "train_samples": len(train_samples),
        "validation_samples": len(val_samples),
        "test_samples": len(test_samples),
        "accelerations": accelerations,
        "note": "Locally trained compact benchmarks; not official pretrained fastMRI checkpoints.",
    }
    (args.out_dir / "deep_selected_models.json").write_text(json.dumps(selected, indent=2), encoding="utf-8")
    print(test_metrics.to_string(index=False))
    print(f"Saved deep benchmark outputs to {args.out_dir.resolve()}")
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-6)
    parser.add_argument("--unet-chans", type=int, default=16)
    parser.add_argument("--varnet-chans", type=int, default=12)
    parser.add_argument("--varnet-cascades", type=int, default=3)
    parser.add_argument("--seed", type=int, default=101)
    parser.add_argument("--log-every", type=int, default=10)
    parser.add_argument("--max-figures", type=int, default=8)
    parser.add_argument("--cpu", action="store_true")
    return parser.parse_args()


def main() -> int:
    return run_from_summary(parse_args())


if __name__ == "__main__":
    raise SystemExit(main())
